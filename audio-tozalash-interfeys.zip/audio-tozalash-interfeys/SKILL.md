---
name: audio-tozalash-interfeys
description: Offline AI asosidagi audio-video shovqin tozalash, suhbatdoshlarni ajratish (diarizatsiya), matnga aylantirish va tarjima tizimining foydalanuvchi (klient) web-interfeysini loyihalash va yaratish. Foydalanuvchi interfeys, UI, dizayn, menyu, sahifa, klient qismi, web sahifa, mockup, prototip, skrinshot (III bob 3.2) yoki "operator oynasi" haqida gapirsa, hatto skill nomini aytmasa ham shu skillni ishlating. Sahifalar: kirish, bosh sahifa, yuklash, navbat, natija (oldin/keyin), suhbatdoshlar, stenogramma va tarjima, arxiv, sozlamalar, administrator.
---

# Audio tozalash tizimi: foydalanuvchi interfeysi

Bu skill magistrlik dissertatsiyasidagi tizimning (`magistrlik-dissertatsiya` skilli) **klient qismi** uchun web-interfeys yaratadi. Tizim: server lokal tarmoqda audio-video faylni shovqindan tozalaydi, suhbatdoshlarni ajratadi, matnga aylantiradi (Whisper) va o'zbek tili hamda 12 til orasida tarjima qiladi (NLLB-200). Operator buni brauzerda boshqaradi.

Avval `/mnt/skills/public/frontend-design/SKILL.md` ni o'qing va uning dizayn jarayoniga (reja → tekshirish → qurish → tanqid) amal qiling. Bu skill unga **mavzuga xos cheklov va talablarni** qo'shadi, ya'ni umumiy "chiroyli sahifa" emas, aniq ishchi vosita yasaladi.

## Foydalanuvchi kim va nima uchun ishlatadi
Professional operator (audio/video bilan ishlovchi xodim), kunlab shu oynada ishlaydi. Unga bezak emas, **tezlik, ishonch va aniqlik** kerak: fayl qayerda, qaysi bosqichda, natija yaxshimi, qanday yuklab olinadi. Dizayn shu ishni yengillashtirishi kerak. Ikkinchi foydalanuvchi: administrator (foydalanuvchilar, audit, zaxira).

## Ish tartibi
1. **Kontekstni oling.** Mavjud bo'lsa `magistrlik-dissertatsiya/references/texnik-topshiriq.md` ni o'qing (14 talab va qo'shimchalar A, B). Sahifalar va talablar xaritasi: `references/sahifalar.md`.
2. **Dizayn rejasi** (frontend-design bo'yicha): rang, shrift, maket, tamoyillar. Foydalanuvchiga qisqa ko'rsating va bitta xabarda ko'pi bilan uchta savol bering (masalan: yorug' yoki to'q mavzu asosiymi, interfeys yozuvi lotin yoki kirill, Java klient ham kerakmi). Javob bo'lmasa, qaysi variantni tanlaganingizni ayting va davom eting.
3. **Qurish.** Avval umumiy qobiq (yon menyu, yuqori panel, mavzu) va 3 ta asosiy sahifa: **Kirish, Yuklash, Natija**. Keyin qolganlari. Hamma sahifani birdaniga emas, 2-3 tadan ko'rsatib, fikr oling.
4. **Tekshirish.** Brauzerda oching, skrinshot oling (imkon bo'lsa), quyidagi "Sifat ro'yxati" bo'yicha o'tib chiqing.
5. **Topshirish.** Fayllarni yuboring va qaysi sahifalar tayyor, qaysilari mock ma'lumot bilan ishlashini ayting.

## Dizayn yo'nalishi
Umumiy shablon (binafsha gradient, bir xil kartalar to'ri) emas. Mavzu: **audio studiya / monitoring asbobi**. Markaziy obraz: to'lqin shakli (waveform) va spektrogramma. Qoidalar:

- **Ma'noli rang.** Rang bezak emas, holat belgisi: "asl (shovqinli)" bir rangda, "tozalangan" boshqasida, bu ikki rang butun interfeysda doim bir xil ma'noda qoladi (to'lqin, pleyer, solishtirish, diagramma). Yana: jarayonda / tayyor / xato / ogohlantirish holatlari uchun alohida, farqlanadigan ranglar. Rangga yolg'iz tayanmang, belgi yoki matn ham qo'shing (rang ko'r foydalanuvchi uchun).
- **To'q va yorug' mavzu** ikkalasi ham, almashtirgich bilan. Operator uzoq o'tiradi, to'q mavzu standart bo'lsin. Kontrast WCAG AA dan past bo'lmasin.
- **Ortiqcha bezak yo'q.** Gradient fon, soyali bir xil kartalar, har bo'limda katta ikonka qo'ymang. Aksent kam va maqsadli: asosiy harakat tugmasi va faol holat.
- **Zichlik.** Bu ishchi vosita: jadval va ro'yxatlar ixcham, lekin o'qiladigan. Bo'sh joy va ierarxiya orqali tartib bering, balandligi ortiqcha kartalar bilan emas.
- **Shrift.** Operator komputeri internetsiz, shuning uchun shriftni **lokal** ulang (woff2 fayl), CDN yo'q. Tanlangan shrift **lotin (o', g' belgilari), kirill va raqamlarni** to'g'ri chiqarsin; vaqt belgilari va raqamlar uchun teng kenglikli raqamlar (tabular-nums).
- **Harakat.** Faqat harakatga javob beradigan animatsiya (ochilish, tasdiq, jarayon). Sahifa yuklanganda bezak animatsiyasi yo'q. `prefers-reduced-motion` ni hurmat qiling.

## Qat'iy cheklovlar (tizim talablaridan)
- **Offline.** Tashqi tarmoqqa hech qanday so'rov yo'q: CDN, Google Fonts, analitika, tashqi ikonka yo'q. Hamma kutubxona, shrift, ikonka lokal. Topshirishdan oldin kodda `http://` va `https://` havolalarini qidiring (faqat lokal API va XML nomlar maydoni ruxsat).
- **Katta fayl.** Yuklash 10 GB gacha: bo'laklab (chunk) va davom ettiriladigan yuklash, to'xtatish/davom etish, tezlik va qolgan vaqt. Faylni brauzer xotirasiga butunlay o'qimang (klient komputerida 8 GB RAM). To'lqin shaklini serverdan tayyor "cho'qqilar" (peaks) sifatida oling, 10 GB audioni brauzerda dekodlamang.
- **Yengil.** Og'ir freymvork va katta paketlar kerak emas. Sodda HTML/CSS/JS yoki juda yengil kutubxona yetarli, sahifa i7-12700 / 8 GB klientda tez ishlasin.
- **Ishonchlilik.** Server qayta ishga tushsa, jarayondagi vazifalar tiklanadi (talab 5): interfeysda bu ko'rinsin ("Server qayta ishga tushdi, vazifalar davom etmoqda"). Aloqa uzilsa, tushunarli xabar va qayta urinish.
- **Xavfsizlik.** Kirishda "login yoki parol noto'g'ri" (qaysi biri ekanini aytmang), urinishlar chegarasi, sessiya muddati tugashi haqida ogohlantirish, rolga qarab menyu (administrator bo'limi oddiy operatorga ko'rinmasin va serverda ham tekshirilsin). Har amal audit jurnaliga tushadi, buni interfeys yashirmasin.
- **Maxfiylik.** Ovoz yozuvlari shaxsiy ma'lumot. Interfeysda fayl nomlari va matnlar tashqariga yuborilmaydi, konsolga yozilmaydi.

## Halollik qoidalari (ko'rsatkichlar haqida)
- Mock (namuna) ma'lumotni **ko'rinadigan "Namuna ma'lumot" belgisi** bilan chiqaring. Tayyor modeldan kelmagan ΔSNR, WER, DER kabi raqamni haqiqiy natija sifatida ko'rsatmang.
- SNR yaxshilanishi **dB da** ko'rsatiladi: ΔSNR = SNR_chiqish − SNR_kirish. Foiz ko'rinishidagi "80–90%" talabini interfeysda o'zingiz izohlamang, kelishilgan ta'rif chiqmaguncha faqat dB ni ko'rsating.
- Mashina tarjimasi yonida doim belgi: "Mashina tarjimasi, tekshirish talab qilinadi". Diarizatsiya va matnga aylantirish natijasi ham tahrir qilish mumkin bo'lsin, chunki ular xatosiz emas.
- Tarjima moduli (NLLB) va stenogramma eksporti hali ilmiy rahbar bilan kelishilmagan "taklif". Interfeysda ular bor bo'lishi mumkin, lekin dissertatsiyada "taklif" deb yozilishini foydalanuvchiga eslating.

## Til va yozuv
- Interfeys matni standart bo'yicha **o'zbek tili, lotin**. Barcha matn bitta lug'atdan (`i18n` obyekti) olinsin, kodga qattiq yozilmasin. Kirill, rus va ingliz variantini qo'shish oson bo'lsin: dissertatsiya kirillda, shuning uchun III bob skrinshotlari uchun **kirill rejimi** foydali.
- Matn yozish qoidasi (frontend-design bo'yicha): foydalanuvchi tilida, sodda; tugma nima bo'lishini aytsin ("Tozalashni boshlash", "Yuklab olish"), bir amal butun oqimda bir nom bilan; xato xabari nima bo'lganini va nima qilish kerakligini aytsin, kechirim so'ramasin; bo'sh ekran harakatga undasin.
- **Ko'p yozuvli matn.** Tarjima natijasida pushtu va dari (arab yozuvi, **o'ngdan chapga**), xitoycha (ieroglif), kirill (rus, qozoq, qirg'iz, tojik) chiqadi. Har til bloki `lang` va `dir` atributiga ega bo'lsin (`dir="rtl"` arab yozuvi uchun), tegishli lokal shriftga ega bo'lsin. Aralash yo'nalishli jadval (chapda LTR original, o'ngda RTL tarjima) buzilmasin.

## Texnik topshiriq shakli
- Papka: `ui/` ichida `index.html`, `css/`, `js/` (`app.js`, `i18n.js`, `api.js`), `fonts/`, `mock/`. Bitta sahifali ilova (hash marshrutlash) yoki sahifa-sahifa, qaysi biri soddaroq bo'lsa.
- **`api.js`** ichida bitta qatlam: mock adapter va haqiqiy server adapteri o'rtasida almashtiriladi, shunda keyin FastAPI bilan ulash oson. Endpointlar ro'yxati `references/sahifalar.md` da (III bobdagi API bilan kelishiladi).
- Foydalanuvchi suhbatda ko'rishi uchun: sessiyada Artifact vositasi bo'lsa, o'z-o'zidan to'liq HTML (shrift/ikonka ichiga joylangan) sifatida chiqarish mumkin. Lekin asosiy topshirish: `ui/` papka (zip) va kerak bo'lsa `SendUserFile`.

## Sifat ro'yxati (topshirishdan oldin)
- [ ] 1366×768 va 1920×1080 da, planshet kengligida ishlaydi; gorizontal sahifa skrolli yo'q.
- [ ] Klaviatura bilan hamma narsaga yetish mumkin, fokus ko'rinadi.
- [ ] To'q va yorug' mavzuda kontrast yetarli.
- [ ] Lotin, kirill, arab yozuvi va xitoycha matn to'g'ri ko'rinadi; RTL bloklar buzilmagan.
- [ ] Har sahifada bo'sh holat, yuklanish, xato va muvaffaqiyat holati bor.
- [ ] Tashqi so'rov yo'q (kodni `http` bo'yicha qidirib tekshirildi).
- [ ] Namuna ma'lumotlar belgilangan; to'qilgan natija raqamlari yo'q.
- [ ] Katta fayl yuklashda faylning hammasi xotiraga o'qilmaydi.
- [ ] Hamma matn `i18n` dan; qattiq yozilgan matn yo'q.
