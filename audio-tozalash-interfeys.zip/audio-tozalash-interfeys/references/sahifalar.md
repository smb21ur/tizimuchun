# Sahifalar, komponentlar va talablar xaritasi

Talab raqamlari `magistrlik-dissertatsiya/references/texnik-topshiriq.md` dagi 14 talabga mos. **A** (matnga aylantirish va Word) va **B** (tarjima) hali kelishilmagan takliflar.

## Mundarija
1. Umumiy qobiq
2. Sahifalar (1-10)
3. Til ro'yxati va kodlar (tarjima)
4. Holatlar (bo'sh, yuklanish, xato)
5. API taklifi (mock va server uchun)
6. Skrinshotlar (III bob uchun)

## 1. Umumiy qobiq
- **Chap menyu** (yig'iladi): Bosh sahifa, Yuklash, Jarayon, Natijalar, Suhbatdoshlar, Stenogramma va tarjima, Arxiv, Sozlamalar, (faqat administrator) Administrator. Faol bo'lim aniq belgilangan. Yig'ilganda ikonka va tooltip.
- **Yuqori panel**: global qidiruv, **server holati** (asosiy server ishlayapti / zaxira serverga o'tilgan / aloqa yo'q; talab 6), navbatdagi vazifalar soni, bildirishnomalar, foydalanuvchi menyusi (ism, rol, mavzu, til, chiqish).
- **Sahifa sarlavhasi** harakat tugmasi bilan; sahifa ichida tablar faqat mazmun haqiqatan bo'lim-bo'lim bo'lsa.
- **Sessiya ogohlantirishi**: muddat tugashidan oldin "Sessiya 2 daqiqada tugaydi, davom etish".

## 2. Sahifalar

### 2.1 Kirish (talab 3, 7)
Login va parol, yoki shaxsiy identifikatsiya kodi bilan kirish (ikkalasi tab/almashtirgich). Parolni ko'rsatish tugmasi. Xato: "Login yoki parol noto'g'ri." Urinishlar chegarasi: "Juda ko'p urinish. N daqiqadan keyin qayta urinib ko'ring." Server holati kichik indikator sifatida. Logo va tizim nomi, ortiqcha reklama matni yo'q.

### 2.2 Bosh sahifa
Qisqacha holat: bugungi fayllar, navbatda, jarayonda, xato bilan tugaganlar. So'nggi ishlar jadvali (fayl, bosqich, holat, vaqt, tez harakat). Server resurslari (CPU, RAM, disk) kichik, oddiy ko'rsatkichlar. Navbat uzoq bo'lsa taxminiy kutish vaqti. "Yangi fayl yuklash" asosiy harakat. Raqamlar mock bo'lsa belgilang.

### 2.3 Yuklash (talab 8, 9, 14)
- Fayl tashlash maydoni va "Fayl tanlash". Qabul qilinadigan formatlar ko'rinsin: wav, mp3, avi, mp4 va boshqalar; 10 GB gacha. Noto'g'ri format yoki hajm darhol tushunarli xabar bilan rad etiladi.
- Ko'p fayl (batch): ro'yxat, har fayl uchun nomi, hajmi, davomiyligi (aniqlangan bo'lsa), yuklash chizig'i, tezlik, qolgan vaqt, to'xtatish/davom etish/olib tashlash.
- Qayta ishlash tanlovlari: rejim (Avtomatik / Professional), kerakli bosqichlar (tozalash, suhbatdoshlarni ajratish, matnga aylantirish, tarjima) belgi katakchalari, til (avtomatik aniqlash yoki qo'lda).
- "Qayta ishlashni boshlash" tugmasi faqat hamma fayl yuklangach va tanlov to'g'ri bo'lsa faol.
- Yuklash uzilsa, qolgan joyidan davom ettirish taklif qilinadi.

### 2.4 Jarayon (navbat) (talab 5, 14)
Jadval: fayl, bosqich, foiz, taxminiy vaqt, ustuvorlik, harakatlar (bekor qilish, ustuvorlikni oshirish). Bosqichlar: navbatda → dekodlash → tozalash → suhbatdoshlarni ajratish → matnga aylantirish → tarjima → yig'ish → tayyor; yoki xato / bekor qilindi. Xato qatori sababini va nima qilish mumkinligini aytsin. Server qayta ishga tushgandan keyin tiklangan vazifalar uchun alohida izoh. Qator ochilsa, bosqichma-bosqich vaqt jurnali.

### 2.5 Natija: oldin va keyin (talab 10, 12)
Bu tizimning markaziy sahifasi, dizaynning "bitta unutilmas elementi" shu yerda.
- Ikki to'lqin shakli yonma-yon yoki ustma-ust: **asl** va **tozalangan** (doimiy ma'noli ranglar). Spektrogramma almashtirgichi.
- Bitta pleyer, "Asl / Tozalangan" tezkor almashtirish (tinglash paytida joyini yo'qotmasdan), A/B solishtirish. Video bo'lsa video pleyer.
- **ΔSNR (dB)** ko'rsatkichi, ta'rifi tooltipda (ΔSNR = SNR_chiqish − SNR_kirish). Boshqa o'lchovlar (masalan, SI-SDR) faqat model haqiqatan hisoblasa. Mock bo'lsa belgilang.
- Shovqin sinfi aniqlangan bo'lsa (shamol, mashina, konditsioner, fon, hayvon, idish-tovoq) ko'rsatilsin.
- Yuklab olish: tozalangan audio/video, formatni tanlash. Takroriy tozalash (boshqa sozlama bilan) tugmasi.

### 2.6 Suhbatdoshlar (diarizatsiya) (talab 11)
- Vaqt chizig'i: har suhbatdosh o'z qatorida (lane), 8 va undan ko'p bo'lganda ham o'qiladigan: ustma-ust gaplashish (overlap) alohida ko'rinadi, ko'p qator bo'lsa skroll yoki yig'ish.
- Suhbatdosh kartasi: nom (tahrirlanadi), umumiy gapirgan vaqt, rang, "faqat shuni tinglash", "shu qismlarni eksport qilish".
- **Ovoz namunasi bo'yicha qidirish**: namuna yuklash, butun fayldan shu shaxs qismlari topilib belgilanadi; ishonch darajasi ko'rsatiladi (haqiqiy model bergan qiymat bo'lsa). Natija noaniq bo'lishi mumkinligi aytiladi.
- Suhbatdoshlarni birlashtirish/ajratish qo'lda tuzatish imkoniyati.
- Maxfiylik eslatmasi: shaxsning ovozini identifikatsiya qilish uchun ruxsat kerak.

### 2.7 Stenogramma va tarjima (A, B: taklif)
- **Stenogramma**: jadval yoki ro'yxat: vaqt, suhbatdosh, matn. Matnni joyida tahrirlash. Vaqtga bosilsa pleyer o'sha joyga o'tadi.
- **Tarjima paneli**: manba til (avtomatik aniqlash yoki tanlash) va maqsad til; yo'nalish almashtirish tugmasi (↔). Til ro'yxati: bo'lim 3. Original va tarjima yonma-yon ustunlarda.
- Doimiy belgi: **"Mashina tarjimasi, tekshirish talab qilinadi."**
- O'zbek matni uchun **yozuv almashtirgichi: lotin / kirill**.
- **Word (.docx) eksporti**: stenogramma, yoki stenogramma + tarjima. Alohida, yuklangan .docx hujjatni tarjima qilish: fayl tashlash, til tanlash, formati saqlanadi, natija .docx.
- RTL: pushtu va dari ustuni `dir="rtl"`, tegishli shrift bilan. Xitoycha uchun ieroglif shrifti.

### 2.8 Arxiv va kutubxona (talab 13)
Kartalar va jadval ko'rinishi almashtirgichi. Qidiruv (fayl nomi, matn, suhbatdosh nomi), filtrlar (sana, format, holat, shovqin turi, til), teglar. Qator harakatlari: ochish, qayta ishlash, yuklab olish, o'chirish (o'chirish oldidan tasdiq, o'chirilgani audit jurnaliga yoziladi). Bo'sh arxiv: "Hali fayl yo'q. Birinchi faylni yuklang."

### 2.9 Sozlamalar (talab 10, 14)
- **Rejim**: Avtomatik / Professional. Professional ochilganda quyidagilar:
  - shovqin turlari (belgi katakchalari: shamol, mashina, konditsioner, fon, hayvon ovozi, idish-tovoq),
  - tozalash kuchi (slayder va raqamli maydon),
  - normalizatsiya (maqsad balandlik, LUFS),
  - diarizatsiya: suhbatdoshlar soni (avto / qo'lda, eng kam va eng ko'p),
  - matnga aylantirish: til (avtomatik yoki tanlash), aniqlik/tezlik,
  - chiqish formati.
- Har sozlama yonida qisqa izoh (tooltip yoki matn). "Standartga qaytarish" va "Saqlash"; saqlanmagan o'zgarish haqida ogohlantirish.
- Shaxsiy: mavzu (to'q/yorug'/tizim), interfeys tili va yozuvi, parolni almashtirish.

### 2.10 Administrator (talab 6, 7) (faqat administrator roli)
- Foydalanuvchilar jadvali: ism, identifikatsiya kodi, rol, holat; qo'shish, bloklash, parolni tiklash.
- **Audit jurnali**: kim, qachon, nima qildi, qaysi fayl; filtr va eksport; o'zgartirib bo'lmaydi.
- **Zaxira**: asosiy va zaxira server holati, oxirgi sinxronizatsiya vaqti, baza nusxasi, "Zaxira nusxa olish" va failover haqida ma'lumot. Xavfli harakatlar (masalan, serverlarni almashtirish) ikki bosqichli tasdiq bilan.
- Tizim holati: xizmatlar (navbat, AI ishchilar), disk bandligi.

## 3. Til ro'yxati va kodlar (tarjima)
Til tanlagichda o'zbek bilan bir qatorda: qozoq, qirg'iz, tojik, turkman, pushtu, dari, rus, ingliz, xitoy, turk, nemis, fransuz (12 til). Har til o'z nomi bilan (endonim) va foydalanuvchi tilidagi nomi bilan ko'rsatiladi. NLLB til kodlari (masalan, `uzn_Latn`, `pbt_Arab`, `prs_Arab`) UI da ko'rinmaydi, faqat API ichida. Kodlarni rasmiy ro'yxatdan tekshiring; xotiradan yozmang. Xitoy uchun soddalashtirilgan va an'anaviy yozuv orasidagi tanlov so'ralsin.

## 4. Holatlar
Har sahifada: **bo'sh** (harakatga undaydi), **yuklanmoqda** (skelet), **xato** (nima bo'ldi, nima qilish kerak, qayta urinish), **muvaffaqiyat** (qisqa tasdiq, masalan "Yuklab olindi"), **aloqa yo'q** (server bilan). Xavfli harakatda tasdiq oynasi, tugma nomi harakatning o'zi ("Faylni o'chirish").

## 5. API taklifi (mock va server uchun)
Dissertatsiyaning III bobidagi API ro'yxati bilan kelishiladi; quyidagi faqat boshlang'ich taklif.

| Maqsad | Usul va yo'l |
|--------|--------------|
| Kirish | `POST /api/v1/auth/login`, `POST /api/v1/auth/logout` |
| Yuklash (bo'laklab) | `POST /api/v1/uploads` (boshlash), `PATCH /api/v1/uploads/{id}` (bo'lak), `HEAD /api/v1/uploads/{id}` (davom ettirish holati) |
| Vazifa yaratish | `POST /api/v1/jobs` (fayl, rejim, bosqichlar, til) |
| Navbat / holat | `GET /api/v1/jobs`, `GET /api/v1/jobs/{id}`, `POST /api/v1/jobs/{id}/cancel` |
| Natija | `GET /api/v1/jobs/{id}/result`, `GET /api/v1/jobs/{id}/peaks` (to'lqin cho'qqilari), `GET /api/v1/jobs/{id}/download` |
| Suhbatdoshlar | `GET /api/v1/jobs/{id}/speakers`, `POST /api/v1/jobs/{id}/speakers/match` (ovoz namunasi) |
| Stenogramma | `GET /api/v1/jobs/{id}/transcript`, `PUT /api/v1/jobs/{id}/transcript` |
| Tarjima | `POST /api/v1/translate` (matn yoki `.docx`), `GET /api/v1/jobs/{id}/translation` |
| Word eksport | `GET /api/v1/jobs/{id}/export.docx` |
| Arxiv | `GET /api/v1/archive` (qidiruv va filtr parametrlari) |
| Administrator | `GET/POST /api/v1/admin/users`, `GET /api/v1/admin/audit`, `GET /api/v1/admin/backup` |

Server har so'rovda rolni tekshiradi; interfeysda yashirish xavfsizlik chorasi emas.

## 6. Skrinshotlar (III bob 3.2 uchun)
Dissertatsiya matni kirillda, shuning uchun skrinshotlarni **kirill rejimida** va mock ma'lumotdagi haqiqiy bo'lmagan nomlar bilan oling. Har rasm raqamlanadi: «Расм 3.x» va izoh. Namuna belgisi ("Namuna ma'lumot") rasm izohida ham aytilsin. Shaxsiy ovoz yozuvi yoki real fayl nomi skrinshotga tushmasin.
