---
name: audio-video-denoising-tizimi
description: Audio video fayllarga ishlov berish nomli offline server-klient tizimini (Windows Server 2019 + Hyper-V Linux VM, DeepFilterNet, FFmpeg, FastDVDnet, whisper.cpp, Pyannote, NLLB-200, Go agent) talablarga ko'ra loyihalash va kodlash.
---

# "Audio video fayllarga ishlov berish" dasturiy tizimi

Magistrlik ishining amaliy qismi. Tizim **to'liq offline**, **lokal tarmoqda**, **server–klient** arxitekturasida ishlaydi. Har bir texnik qaror dissertatsiyaning III–IV boblarida asoslanadi (`magistrlik-dissertatsiya-boblari` skilli bilan birga ishlating).

## 0. Qabul qilingan qarorlar (o'zgartirmang)

1. **Server:** Windows Server 2019 (xost) + **Hyper-V**, ichida **Linux virtual mashinalar** (Ubuntu Server LTS). Linux steki (PostgreSQL, RabbitMQ, Celery, ClamAV, Patroni, Keepalived, GlusterFS, ELK) VM'lar ichida ishlaydi.
2. **Klient:** web interfeys + installer o'rnatadigan **lokal agent**. Agent **Go 1.20** da yoziladi (Windows 7 ni qo'llaydigan oxirgi Go versiyasi, bitta .exe, runtime kerak emas). Zaxira variant: **Python 3.8** (Win7 uchun oxirgi versiya) + PyInstaller.

## 1. Texnik topshiriq talablari (majburiy)

1. Offline, AI asosida, katta hajmdagi (10 GB gacha) audio-video fayllarni professional darajada tozalash.
2. Ikki qism: **Server** (ishlov beradi, natijani qaytaradi) va **Foydalanuvchi** (operator ish joyi).
3. Login/parol orqali kirish; parollar **xeshlangan** (Argon2id yoki bcrypt).
4. Ma'lumot almashinuvi faqat lokal tarmoq orqali.
5. Elektr uzilishi, UPS tugashi, OS xatosidan keyin qayta yuklanganda **barcha xizmatlar avtomatik ishga tushadi**.
6. **Zaxira (rezerv) server** va ma'lumotlarni to'liq ko'chirish imkoniyati.
7. Har bir foydalanuvchi amallari tarixi (audit).
8–9. Fayl yuklash: wav, mp3, avi, mp4 va boshqalar.
10. "Audio Processing" (tozalash + normalizatsiya) va tayyor natijani yuklab olish.
11. Speaker diarization (6–8+ suhbatdosh). **Ovoz namunasi** yuklanganda shu shaxs gapirgan barcha qismlarni topish va ajratish.
12. Deep Learning, "80–90% gacha SNR yaxshilash", full offline.
13. Arxiv va kutubxona.
14. Shovqin turlari: shamol, mashina, konditsioner, fon, hayvon, idish-tovoq; **Avtomatik** va **Professional** rejim; 10 GB fayllar; **Batch** rejim.

### Apparat
- **Server:** 2× Intel Xeon Gold 6240 (har biri 18 yadro / 36 oqim, AVX-512 + VNNI — INT8 uchun qulay), 8×32 GB RAM (256 GB), 2×960 GB SSD, 8×8 TB HDD, RAID kontroller, ikki karra quvvat bloki, 10 GbE. **GPU yo'q** — barcha modellar CPU uchun optimallashtiriladi.
- **Klient:** Intel i7-12700, 8 GB RAM, 500 GB SSD + 1 TB HDD; Windows 7/10/11.

## 2. Olti mikroxizmat

| # | Xizmat | Vosita | CPU optimallashtirish |
|---|---|---|---|
| 1 | Shovqindan tozalash | DeepFilterNet3 (48 kHz) | ONNX Runtime / OpenVINO, INT8/FP16 |
| 2 | Videodan audioni ajratish va qayta birlashtirish | FFmpeg | – |
| 3 | Video sifatini yaxshilash | FastDVDnet | OpenVINO; ixtiyoriy (CPU'da og'ir, faqat so'ralganda) |
| 4 | Nutqni matnga | whisper.cpp + Whisper large-v3 (GGUF, q5/q8) | OpenVINO encoder, ko'p oqim |
| 5 | Suhbatdoshlarni ajratish | Pyannote.audio 3.x | ONNX embedding; modellar bir marta yuklab olinib lokal saqlanadi |
| 6 | Tarjima (.docx ham) | NLLB-200 distilled 600M/1.3B (CTranslate2, INT8) | CTranslate2 |

Tarjima tillari (o'zbek ↔ 12 til), NLLB kodlari: uzn_Latn ↔ kaz_Cyrl, kir_Cyrl, tgk_Cyrl, tuk_Latn, pbt_Arab (pushtu), prs_Arab (dari), tur_Latn, zho_Hans, rus_Cyrl, eng_Latn, fra_Latn, deu_Latn. Word fayl tarjimasida python-docx bilan matn bo'laklari (run) tarjima qilinib, formatlash saqlanadi.

NLLB-200 litsenziyasi CC-BY-NC (notijorat) — dissertatsiyada qayd eting.

### Ovoz namunasi bo'yicha qidirish
Namuna → speaker embedding → diarizatsiya klasterlari embeddinglari bilan kosinus o'xshashlik → chegaradan (threshold) yuqori segmentlar belgilanadi va alohida eksport qilinadi.

### Shovqin turlari va rejimlar
- **Avtomatik:** standart DeepFilterNet3 + LUFS normalizatsiya (−16/−23 LUFS).
- **Professional:** shovqin turi katakchalari, tozalash kuchi 0–100 (DeepFilterNet `atten_lim_db` ga moslanadi), LUFS maydoni, suhbatdoshlar soni (avto/qo'lda), chiqish formati.
- Shovqin turlari bo'yicha fine-tuning qilingan DeepFilterNet3 vaznlari (dissertatsiyadagi ilmiy yangilik) alohida profil sifatida yuklanadi.

## 3. Server arxitekturasi (Windows Server 2019 + Hyper-V)

### Xost darajasi
- Windows Server 2019 faqat gipervizor vazifasini bajaradi (Hyper-V roli, boshqa og'ir xizmatlar o'rnatilmaydi).
- Disklar RAID kontrollerda: 2×960 GB SSD → **RAID 1** (xost OS + VM disklari + PostgreSQL), 8×8 TB HDD → **RAID 6** (fayllar arxivi). Har ikkala hajm **BitLocker** bilan shifrlanadi (Data at Rest).
- VM disklari — **fixed-size VHDX** (dinamik emas, I/O tezroq). Arxiv uchun alohida katta VHDX HDD hajmida.
- Tarmoq: Hyper-V **External virtual switch** 10 GbE portga; ichki trafik uchun **Internal switch** (VM'lar orasida).
- Har VM uchun **Processor compatibility mode o'chirilgan** bo'lishi kerak, aks holda AVX-512/VNNI VM ichida ko'rinmaydi va INT8 tezlashuvi yo'qoladi.
- NUMA: 2 ta protsessor = 2 ta NUMA tugun. AI worker VM'larini har biri bitta NUMA tugunga sig'adigan qilib ajrating.

### VM taqsimoti (36 yadro / 72 oqim, 256 GB RAM)

| VM | Vazifa | vCPU | RAM |
|---|---|---|---|
| Xost zaxirasi | Windows Server + Hyper-V | 4 | 16 GB |
| VM-1 API | Nginx, FastAPI, statik web UI | 8 | 16 GB |
| VM-2 Data | PostgreSQL + PgBouncer, RabbitMQ, Redis | 8 | 32 GB |
| VM-3a AI Worker | Celery: denoise, STT, diarizatsiya (NUMA 0) | 24 | 88 GB |
| VM-3b AI Worker | Celery: video, tarjima, denoise (NUMA 1) | 24 | 88 GB |
| VM-4 Monitoring | ELK (Elasticsearch, Logstash, Kibana) | 4 | 16 GB (yoki VM-2 ichida yengil variant) |

Hyper-V **resource control** orqali VM-3 uchun CPU limit ~90% qo'yiladi — API va baza uchun doim 10–15% zaxira qoladi. Dynamic Memory AI VM'larda **o'chiriladi** (statik RAM). VM ichida Celery worker'larga systemd `CPUQuota`/`MemoryMax` bilan qo'shimcha chegara.

### Avtomatik ishga tushish (elektr uzilishidan keyin)
1. Server BIOS/iDRAC: **"AC Power Recovery = On"** (tok qaytganda server o'zi yonadi).
2. Hyper-V har VM uchun: `Set-VM -AutomaticStartAction Start -AutomaticStartDelay <soniya>` — tartib: VM-2 (0 s) → VM-1 (60 s) → VM-3a/3b (90 s) → VM-4.
3. `Set-VM -AutomaticStopAction ShutDown` — UPS signalida VM'lar tartibli o'chadi.
4. VM ichida barcha xizmatlar systemd `Restart=always` va `enable`; Docker ishlatilsa `restart: unless-stopped`.
5. UPS bilan aloqa (masalan, APC PowerChute yoki NUT) — batareya tugashidan oldin xostni to'g'ri o'chiradi.

### Ishlov berish oqimi (asinxron)
1. Klient faylni **bo'laklab** (chunked, resumable, masalan tus protokoli) yuklaydi; API faylni 1 MB bo'laklarda diskka yozadi, RAMga to'liq yuklamaydi.
2. Tekshiruvlar: magic bytes (python-magic), ClamAV skan, hajm chegarasi, SHA-256 xesh.
3. Xesh oldin uchragan va natija tayyor bo'lsa — deduplikatsiya, AI chetlab o'tiladi.
4. Server avtomatik **tasdiqnoma** beradi (xesh mos kelsa); aks holda xato xabari.
5. API darhol "Vazifa qabul qilindi" (task_id) qaytaradi; RabbitMQ'ga faqat task_id va JSON parametrlar yuboriladi (fayl emas).
6. **Dinamik marshrutizatsiya:** worker faqat tanlangan xizmatlarni bajaradi va faqat kerakli modellarni yuklaydi. Ustuvorlik: oddiy / muhim / o'ta muhim → RabbitMQ `x-max-priority`.
7. Katta fayllar FFmpeg bilan 30–60 s segmentlarga bo'linadi (chegaralarda overlap + crossfade), ishlanadi, so'ng qayta birlashtiriladi (muxing).
8. Bosqich holati (navbatda / tozalanmoqda / diarizatsiya / tugadi) WebSocket orqali klientga.
9. Natija NAS'ga yoziladi, klient yuklab oladi va **qabul tasdiqnomasini** yuboradi (xesh tekshiruvi bilan). Xato bo'lsa — qayta yuborish.

### Saqlash
- SSD (RAID 1): OS, PostgreSQL + WAL, temp fayllar.
- HDD (RAID 6): asl va natija fayllar, arxiv. Eski fayllar SSD'dan HDD'ga avtomatik ko'chiriladi.
- Shifrlash: xostda BitLocker; zarur bo'lsa VM ichida LUKS.

### PostgreSQL
- Jadvallar: users, roles, sessions, files, tasks, task_steps, receipts (tasdiqnomalar), transfers (kim→kimga), messages (chat), speakers, voice_samples, audit_logs, settings.
- Barcha PK — UUID. `status`, `created_at`, `user_id` ga B-Tree indeks.
- `postgresql.conf` (32 GB RAM VM uchun): shared_buffers=8GB, effective_cache_size=24GB, work_mem=32MB, maintenance_work_mem=2GB, autovacuum_vacuum_scale_factor=0.05, autovacuum_analyze_scale_factor=0.02.
- **O'chirilmaydigan yozuvlar:** qabul qilingan / yuborilgan fayllar va tasdiqnomalar haqidagi yozuvlar hamda `audit_logs` — append-only (UPDATE/DELETE trigger yoki RULE bilan taqiqlanadi, admin ham o'chira olmaydi). Admin faqat **fayllarning o'zini** o'chira oladi (1 oydan eski fayllarni tozalash funksiyasi). Klientdagi "korzina" — soft-delete belgisi, bazadan o'chirish emas.

### Xavfsizlik
- JWT (qisqa muddatli access + refresh), RBAC: `user`, `admin`, `auditor`.
- IDOR himoyasi: har so'rovda `owner_id` tekshiruvi.
- Pydantic validatsiya, faqat parametrlangan so'rovlar (f-string SQL yo'q), saralash ustunlari uchun oq ro'yxat.
- Fayl nomi o'rniga UUID (path traversal himoyasi).
- Ichki xizmatlar orasida mTLS; lokal CA. Klientlarga ham shu CA sertifikati installer orqali o'rnatiladi (HTTPS ogohlantirishsiz).
- Loglar: ELK — noto'g'ri JWT/login urinishlari bo'yicha ogohlantirish.
- Brute-force himoyasi: 5 noto'g'ri urinishdan keyin vaqtinchalik blok.
- Xost: Windows Firewall faqat kerakli portlar; VM ichida ufw/iptables.

### Uzluksizlik va zaxira (HA/DR)
- Zaxira server — ikkinchi xuddi shunday Windows Server 2019 + Hyper-V xost.
- **Ilova darajasi (asosiy, real vaqt):** PostgreSQL streaming replication + Patroni (avtomatik failover); fayllar GlusterFS (replica 2) yoki lsyncd+rsync; RabbitMQ klaster + quorum queues; Keepalived + virtual IP (klientlar doim bitta manzilga ulanadi).
- **VM darajasi (qo'shimcha):** **Hyper-V Replica** — VM'larni zaxira xostga 30 s / 5 min intervalda nusxalaydi; ilova darajasi ishlamay qolsa butun VM'ni tiklash uchun.
- Admin panelida zaxira server holati va "zaxira nusxa olish" tugmasi (pg_basebackup + fayllar snapshot).

## 4. Klient (web interfeys)

### Brauzer cheklovlari (Windows 7)
Windows 7 dagi oxirgi brauzerlar: **Chrome 109** va **Firefox ESR 115**. Web UI shu brauzerlarda ishlashi shart:
- JS build maqsadi ES2020; CSS nesting, `@container`, `color-mix()` kabi yangi imkoniyatlardan foydalanmang yoki fallback bering.
- Inter shrifti va Lucide ikonkalari lokal fayllar sifatida.
- Har bir sahifa Chrome 109 da sinab ko'riladi.

### Umumiy dizayn
- Tizim nomi header'da: **"Audio video fayllarga ishlov berish"** + signal/mikrofon ikonkasi.
- Tillar: o'zbek (lotin), rus, ingliz (i18n JSON fayllar).
- Mavzu: dark (asosiy) va light; aksent #6C63FF; 12–16 px radius; animatsiya 150–250 ms; planshet va monitor uchun responsive.
- Yuqorida: qidiruv, server holati indikatori (yashil/sariq/qizil), bildirishnomalar, profil (ism, rol, chiqish).
- Chapda yig'iladigan sidebar: "MENYU" yozuvi, bo'limlar, pastida 1 oylik kalendar. Faol bo'lim ajralib turadi; sidebar o'zgarmaydi.
- Footer: admin F.I.Sh., telefon raqami, o'ngda chat ikonkasi.
- Har sahifada: empty state illyustratsiyasi, skeleton yuklanish, toast xabarlar.

### Foydalanuvchi bo'limlari
1. **Fayl jo'natish:** fayl yo'li/nomi maydoni + "Ochish" tugmasi; drag & drop; muhimlilik darajasi (oddiy/muhim/o'ta muhim); qabul qiluvchi; mikroxizmat kartalari (o'z rasmi bilan, bir nechtasini tanlash mumkin); har fayl uchun progress, pauza/davom; batch ro'yxati; "Qayta ishlashni boshlash" va rejim tanlash. Yuborilgach → "Yuborilgan fayllar".
2. **Kelgan fayllar:** nomi, hajmi, vaqti, kimdan; "Yuklab olish" (agent orqali avtomatik `C:\Audio video denoising\Kelgan fayllar\YYYY-MM-DD\`); "Tasdiqnoma yuborish" → fayl "Qabul qilingan"ga o'tadi.
3. **Qabul qilingan fayllar:** ma'lumotlar + tasdiqnoma kim tomonidan yuborilgani; natijalar: oldin/keyin waveform va spektrogramma, "Asl"/"Tozalangan" pleyer almashtirgich, video pleyer, ΔSNR (dB), yuklab olish; o'chirish → korzina.
4. **Yuborilgan fayllar:** nomi, hajmi, vaqti, kim, kimga, tasdiqnoma belgisi va kim bergani; o'chirish → korzina.
5. **Tasdiqnomalar:** ikki qism — kelgan va jo'natilgan; o'chirish → korzinaning tegishli bo'limi.
6. **Statistika:** oyma-oy yuborilgan/qabul qilingan fayllar soni va hajmi (diagramma + jadval); agent orqali `C:\Audio video denoising\Statistika\` ga yozib boriladi.
7. **Suhbatdoshlar:** vaqt chizig'ida har spiker boshqa rangda (8+), spiker kartalari (nom berish, umumiy gapirish vaqti), "Ovoz namunasini yuklash", spiker qismlarini eksport.
8. **Arxiv va kutubxona:** karta/jadval ko'rinishi, qidiruv, filtrlar (sana, format, holat, shovqin turi), teglar, qayta ochish va qayta ishlash (faylni qayta yuklamasdan yangi xizmat qo'shish).
9. **Sozlamalar (tablar):** Avtomatik/Professional rejim va parametrlari; papkalar (kelgan va yuborilgan fayllar papkasi o'zgartiriladi, qolganlari o'zgarmaydi); bildirishnoma ovozlari (Media papkasidagi .wav tanlanadi: fayl, tasdiqnoma, chat uchun); til; mavzu; har sozlama yonida tooltip; "Saqlash" va "Standartga qaytarish".
10. **Korzina:** 4 qism (kelgan fayllar, yuborilgan fayllar, kelgan tasdiqnomalar, jo'natilgan tasdiqnomalar), har birida "Tozalash".
11. **Chat:** WebSocket; kirganda avtomatik online status; klientlar va admin bilan yozishma.

Agent ishlamayotgan bo'lsa UI ogohlantiradi va oddiy brauzer yuklab olishiga o'tadi (fayl yo'qolmaydi).

### Admin bo'limlari
Foydalanuvchilar (F.I.Sh., login, xeshlangan parol ko'rinishi, oxirgi kirish, amallari; qo'shish / o'chirish / bloklash, rol), qabul qilingan fayllar, yuborilgan fayllar, tasdiqnomalar, statistika (hozir ishlanayotgan fayllar va hajmi, baza hajmi, worker yuklamasi), audit jurnali (filtrli, CSV/JSON eksport), zaxira server holati, 1 oydan eski fayllarni o'chirish, sozlamalar, korzina, chat.

## 5. Klient lokal agenti (Go 1.20)

Brauzer o'zi `C:\` dagi papkalarga yoza olmaydi, shuning uchun bu ishni agent bajaradi.

### Texnik asos
- **Go 1.20.x** bilan `GOOS=windows GOARCH=amd64` (32-bitli Win7 bo'lsa `386` ham) build. Go 1.21+ Win7'ni qo'llamaydi — versiyani `go.mod` da `go 1.20` deb qotiring, bog'liq kutubxonalarni ham Go 1.20 ga mos versiyada tanlang.
- Windows xizmati sifatida: `golang.org/x/sys/windows/svc` (Go 1.20 ga mos eski versiya). Xizmat `Automatic` rejimda, kompyuter yonganda o'zi ishga tushadi.
- Faqat `127.0.0.1:47800` da tinglaydi (tashqaridan ulanib bo'lmaydi).

### Agent API (localhost)
| Endpoint | Vazifa |
|---|---|
| `GET /health` | agent ishlayaptimi, versiyasi |
| `POST /download` | serverdan faylni oqim bilan yuklab, `Kelgan fayllar\YYYY-MM-DD\` ga yozadi, SHA-256 ni tekshiradi, natijani (ok/xato) qaytaradi — shu asosda UI qabul tasdiqnomasini yoki xato xabarini serverga yuboradi |
| `POST /pick-file` | Windows fayl tanlash oynasini ochib, yo'lni qaytaradi ("Ochish" tugmasi uchun) |
| `POST /upload` | tanlangan lokal faylni serverga bo'laklab yuboradi (pauza/davom bilan) |
| `POST /stats` | statistikani `Statistika\` papkasiga CSV/JSON qilib yozadi |
| `POST /play-sound` | `Media\` dagi tanlangan .wav ni chaladi |
| `GET/PUT /settings` | papka yo'llari (faqat "Kelgan fayllar" va "Yuborilgan fayllar" o'zgaradi) |

### Agent xavfsizligi
- CORS: faqat server virtual IP manzilidagi web UI origin'iga ruxsat.
- Chrome'ning Private Network Access preflight so'rovlariga `Access-Control-Allow-Private-Network: true` bilan javob beradi.
- Juftlash (pairing) tokeni: foydalanuvchi tizimga kirganda server bergan token agentga beriladi; tokensiz so'rovlar rad etiladi (boshqa saytlar agentdan foydalana olmaydi).
- Fayl yo'llari faqat `C:\Audio video denoising\` va sozlamalarda tanlangan papkalar ichida (path traversal himoyasi).

### Installer
Inno Setup (Windows 7 ni qo'llaydigan versiyasini tekshiring) yoki NSIS:
- `C:\Audio video denoising\` va ichida: `Kelgan fayllar`, `Yuborilgan fayllar`, `Kelgan tasdiqnomalar`, `Yuborilgan tasdiqnomalar`, `Korzina`, `Media` (3 ta .wav), `Statistika`. Joriy foydalanuvchiga yozish huquqi beriladi.
- Agent .exe ni o'rnatib, Windows xizmati sifatida ro'yxatdan o'tkazadi va ishga tushiradi.
- Server CA sertifikatini "Trusted Root" ga qo'shadi.
- Ish stoli yorlig'i (server virtual IP dagi web UI'ni ochadi).
- Uninstall: xizmatni to'xtatib o'chiradi; foydalanuvchi fayllari papkasini o'chirmaydi.

## 6. Loyiha tuzilmasi

```
audio-video-ishlov/
  server/
    api/            # FastAPI: auth, files, tasks, receipts, chat, admin, audit
    workers/        # Celery: denoise, extract, video_enhance, stt, diarize, translate
    models/         # ONNX/OpenVINO/GGUF/CTranslate2 vaznlari (offline)
    db/             # Alembic migratsiyalar, schema.sql, audit triggerlari
    deploy/
      hyperv/       # PowerShell: VM yaratish, CPU/RAM, autostart, Hyper-V Replica
      linux/        # nginx, postgresql.conf, rabbitmq, keepalived, patroni, systemd unitlari
    tests/
  client/
    web/            # HTML/CSS/JS, i18n/{uz,ru,en}.json, lokal shrift va ikonkalar (Chrome 109 mos)
    agent/          # Go 1.20: main.go, service.go, api.go, download.go, go.mod
    installer/      # Inno Setup skripti, media/*.wav, ca.crt
  admin/web/
  docs/             # arxitektura sxemalari, API tavsifi, foydalanuvchi qo'llanmasi
  training/         # DeepFilterNet3 va Whisper fine-tuning skriptlari
```

## 7. Ishlab chiqish bosqichlari

1. Texnik topshiriqni tasdiqlash.
2. UI prototipi (mock ma'lumotlar bilan, HTML/CSS/JS, offline) — foydalanuvchi va admin sahifalari.
3. Hyper-V VM'larini yaratish skriptlari va Linux bazaviy sozlash.
4. Baza sxemasi va API.
5. Worker'lar: avval DeepFilterNet + FFmpeg, keyin whisper.cpp, Pyannote, NLLB, FastDVDnet.
6. Tasdiqnomalar, chat, arxiv, statistika.
7. Go agent va installer.
8. Xavfsizlik, audit, HA/DR.
9. Sinov (IV bob uchun natijalar).

Har bosqichda ishlaydigan kod beriladi; kod yozishdan oldin tegishli kutubxona hujjatini tekshiring (versiyalar tez o'zgaradi).

## 8. Sinov va baholash (IV bob uchun)

- Sifat: PESQ, STOI, SI-SDR, DNSMOS, ΔSNR (dB); "80–90% SNR yaxshilash" talabi qanday o'lchanganini aniq yozing (masalan, kirish SNR'iga nisbatan foizda) va faqat haqiqiy o'lchov natijasini keltiring.
- STT: WER/CER; diarizatsiya: DER; tarjima: BLEU/chrF.
- Unumdorlik: RTF (real-time factor), bir vaqtda N ta fayl, 10 GB fayl, RAM cho'qqisi.
- Ishonchlilik: elektr uzilishi simulyatsiyasi (xostni o'chirib yoqish → barcha VM va xizmatlar o'zi turadimi), master server o'chirilganda failover vaqti, ma'lumot yo'qolmasligi.
- Klient: Windows 7 (Chrome 109), 10, 11 da agent va UI sinovi.
- Xavfsizlik: noto'g'ri fayl turi, zip-bomb, brute-force, IDOR, agentga begona sayt so'rovi testlari.

Natija raqamlari to'qilmaydi — faqat haqiqiy sinovdan olinadi.
