---
name: ilmiy-maqola-finetuning
description: DeepFilterNet3 yoki Whisper large-v3 modellarini fine-tuning qilish mavzusida ilmiy maqola variantlarini taklif qilish va tanlangan maqolani yozish.
---

# Fine-tuning bo'yicha ilmiy maqolalar

Magistrlik dissertatsiyasi (offline AI audio-video shovqin tozalash) doirasida 2 ta maqola tayyorlanadi:
1. **DeepFilterNet3** ni fine-tuning qilish.
2. **Whisper large-v3** ni fine-tuning qilish.

## 1-qadam: variantlarni taklif qilish

Maqola yozishdan oldin har mavzu bo'yicha 3–4 variant taklif qiling: sarlavha, ilmiy yangilik, dataset, kutilgan natija, mos jurnal turi. Foydalanuvchi tanlaganidan keyingina yozing.

Variant namunalari:

**DeepFilterNet3:**
- A. O'zbek nutqi va mahalliy shovqinlar (bozor, transport, to'y) bilan fine-tuning — til va muhitga moslashtirish.
- B. Past SNR (−5…5 dB) sharoitida fine-tuning va CPU'da real vaqt ko'rsatkichlari.
- C. Telefon/past sifatli mikrofon yozuvlari uchun moslashtirish (8–16 kHz → 48 kHz).
- D. Shovqin tozalashning keyingi ASR (Whisper) aniqligiga ta'siri: WER bo'yicha baholash.

**Whisper large-v3:**
- A. O'zbek tili uchun LoRA bilan parametr-tejamkor fine-tuning (Common Voice, FLEURS, USC).
- B. Shovqinli o'zbek nutqi uchun noise-augmented fine-tuning va DeepFilterNet3 bilan birgalikdagi pipeline.
- C. whisper.cpp'ga o'tkazish va kvantlashning (q5/q8) WER va tezlikka ta'siri — offline tizimlar uchun.
- D. Kirill/lotin yozuvini boshqarish va o'zbek tili uchun matn normallashtirish.

## Maqola tuzilishi (IMRaD)

1. **УДК** indeksi.
2. Sarlavha (o'zbek, rus, ingliz).
3. Muallif(lar), tashkilot, email — foydalanuvchidan so'raladi, to'qib yozilmaydi.
4. **Аннотация / Annotatsiya / Abstract** — 3 tilda, har biri 100–150 so'z.
5. **Калит сўзлар / Ключевые слова / Keywords** — 5–8 ta.
6. **Кириш** — dolzarblik, muammo, maqsad.
7. **Адабиётлар таҳлили** — qisqa, asosiy ishlar.
8. **Методология** — model arxitekturasi, matematik asoslar, dataset, fine-tuning sozlamalari.
9. **Натижалар** — jadvallar (oldin/keyin), grafiklar.
10. **Муҳокама** — natijalar tahlili, cheklovlar.
11. **Хулоса**.
12. **Адабиётлар** — 10–15 ta, asosan rus tilidagi va asl maqolalar.

Hajm: 6–10 bet (jurnal talabiga qarab).

## Matematik asoslar

**DeepFilterNet3:**
- Shovqinli signal modeli: x(t) = s(t) + n(t); STFT domenida X(k,m) = S(k,m) + N(k,m).
- 1-bosqich — ERB-gain: Ŝ_ERB(k,m) = G(b,m)·X(k,m), b — ERB polosasi.
- 2-bosqich — deep filtering (past chastotalar): Y(k,m) = Σ_{i=0}^{N} C(k,i,m)·X(k, m − i + l).
- SNR bo'yicha aralashtirish: y = s + α·n, α = sqrt(P_s / (P_n·10^{SNR/10})).
- Yo'qotish: multi-resolution spektral yo'qotish (magnituda + kompleks spektr).
- Metrikalar: PESQ, STOI, SI-SDR = 10·log₁₀(‖αs‖² / ‖αs − ŝ‖²), DNSMOS.

**Whisper large-v3:**
- Kirish: 30 s oyna, 128 ta Mel polosa, log-Mel spektrogramma.
- Transformer encoder-decoder; attention: softmax(QKᵀ/√d_k)·V.
- Yo'qotish: L = −Σ log P(y_t | y_<t, X).
- LoRA: W = W₀ + (α/r)·B·A, B ∈ ℝ^{d×r}, A ∈ ℝ^{r×k}, r ≪ min(d,k).
- Metrikalar: WER = (S + D + I) / N, CER.

Model bo'yicha har bir raqam (parametrlar, qatlamlar, kadr uzunligi) asl maqola yoki rasmiy repozitoriydan tekshiriladi.

## Datasetlar

- Nutq: Common Voice (uz), FLEURS (uz_uz), USC (ISSAI Uzbek Speech Corpus), VCTK.
- Shovqin: DEMAND, MUSAN, DNS Challenge shovqinlari, o'zingiz yozgan real shovqinlar.
- Bo'linish: train/validation/test; test to'plami trainga aralashmasin.

## Eksperiment natijalari haqida halollik

Natijalar jadvalidagi raqamlar faqat haqiqiy eksperimentdan olinadi. Agar foydalanuvchi hali o'qitishni o'tkazmagan bo'lsa:
- jadvalni bo'sh kataklar yoki "[натижа]" belgisi bilan qoldiring;
- eksperimentni o'tkazish uchun tayyor kodni (Python, PyTorch, HuggingFace transformers/peft, DeepFilterNet repozitoriysi) taklif qiling;
- to'qima raqam yozmang.

## Uslub

- Asosiy til: o'zbek, kirill alifbosi (yoki jurnal talab qilgan til).
- Ilmiy, aniq, inson yozgandek tabiiy; manbadan so'zma-so'z ko'chirmasdan, o'z so'zlari bilan bayon va havola.
- Times New Roman 14 pt, 1,5 interval (jurnal boshqa talab qo'ymasa).
- Havolalar matnda [N]; manbalar haqiqiy va tekshirilgan bo'lishi shart.

## Chiqarish

`docx` skillining SKILL.md faylini o'qib, maqolani .docx qilib yarating. Formulalar Word tenglamasi sifatida. Vizual tekshirib, SendUserFile bilan yuboring.
