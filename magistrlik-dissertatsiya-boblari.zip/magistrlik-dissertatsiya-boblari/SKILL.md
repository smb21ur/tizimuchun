---
name: magistrlik-dissertatsiya-boblari
description: Offline AI audio-video shovqin tozalash mavzusidagi magistrlik dissertatsiyasining II, III, IV boblarini ishlab chiqilayotgan tizimga mos, kirill o'zbek tilida, ilmiy uslubda yozish va .docx qilib berish.
---

# Magistrlik dissertatsiyasi boblarini yozish

Dissertatsiya amaliy qismi — "Audio video fayllarga ishlov berish" tizimi. Tizim tafsilotlari `audio-video-denoising-tizimi` skillida. Dissertatsiyadagi har bir arxitektura, xavfsizlik va model tavsifi o'sha tizimga **mos** bo'lishi shart.

## Dissertatsiya mavzusi

**«Offline режимда, сунъий интеллект асосида ишлайдиган аудио – видео маълумотларни шовқиндан тозалаш дастурий таъминоти ишлаб чиқиш»**

## Ish rejasi va mazmun xaritasi

- **КИРИШ** va **I БОБ** tayyor (chet el dasturlari va AI modellar tahlili; xulosada DeepFilterNet, VoiceFixer, Pyannote, NeMo, Whisper tanlangan).
- **II БОБ.** Сунъий интеллект асосида ишлайдиган аудио ва видео маълумотларни шовқиндан тозалашда фойдаланиладиган алгоритмлар ва дастурий кутубхоналарнинг технологик асосларини тадқиқ этиш.
  - **2.1** — olti mikroxizmat vositasini chuqur tadqiq qilish: DeepFilterNet3, FFmpeg, FastDVDnet, Whisper large-v3 / whisper.cpp, Pyannote.audio, NLLB-200 (har biri pastdagi sxema bo'yicha) + CPU optimallashtirish (ONNX Runtime, OpenVINO, INT8 kvantlash, CTranslate2).
  - **2.2** — umumiy algoritm: yuklash → tekshirish (magic bytes, antivirus, xesh) → dinamik marshrutizatsiya → FFmpeg segmentatsiya → DeepFilterNet3 → Pyannote → whisper.cpp → NLLB-200 → birlashtirish (muxing) → tasdiqnoma. Video tarmog'i: FFmpeg → FastDVDnet → audio bilan birlashtirish. Ovoz namunasi bo'yicha shaxsni topish algoritmi. DeepFilterNet3 va Whisper fine-tuning metodikasi (ilmiy yangilik). Blok-sxemalar.
  - II-Боб бўйича хулосалар
- **III БОБ.** Offline режимда сунъий интеллект асосида аудио ва видео маълумотларни шовқиндан тозалаш тизимини ишлаб чиқиш.
  - **3.1** — server qismi: apparat, Windows Server 2019 + Hyper-V ustida Linux VM'lar (API / baza+navbat / AI worker, NUMA bo'yicha taqsimlash), FastAPI + RabbitMQ + Celery asinxron arxitekturasi, "modulli kaskad arxitekturasi va resurslarni dinamik taqsimlash", PostgreSQL sxemasi va sozlamalari, saqlash qatlamlari (SSD/HDD), xavfsizlik (JWT, RBAC, IDOR, mTLS, ClamAV, BitLocker, append-only audit, ELK), uzluksizlik (avtomatik ishga tushish, replikatsiya, Patroni, Keepalived, Hyper-V Replica, zaxira server — "Disaster Recovery va High Availability").
  - **3.2** — foydalanuvchi interfeysi: 3 tilli web UI, menyu bo'limlari, fayl jo'natish, tasdiqnomalar mexanizmi, natijalar vizualizatsiyasi (waveform, spektrogramma, ΔSNR), diarizatsiya vaqt chizig'i, arxiv va kutubxona ("User-Centric Data Lifecycle Management"), chat, admin paneli, Go 1.20 dagi lokal agent va installer (Windows 7 mosligi asoslanadi). Ekran rasmlari bilan.
  - III-Боб бўйича хулосалар
- **IV БОБ.** Синов ва самарадорлик: 4.1 — funksional, unumdorlik, ishonchlilik (failover, elektr uzilishi), xavfsizlik testlari; 4.2 — PESQ, STOI, SI-SDR, ΔSNR, WER/CER, DER, BLEU/chrF, RTF; fine-tuning oldi/keyin taqqoslash; mavjud dasturlar (I bobdagi) bilan taqqoslash.
- **ХУЛОСА**, **ФОЙДАЛАНИЛГАН АДАБИЁТЛАР РЎЙХАТИ**

Navbatdagi ustuvor vazifa: II va III boblar va 2 ta maqola (1 oy).

## I bob bilan muvofiqlik

I bob xulosasida VoiceFixer va NVIDIA NeMo tilga olingan, yakuniy stek esa boshqacha. II bob boshida stekning nima uchun aniqlashtirilgani asoslanadi: server GPU'siz (Xeon Gold 6240), shuning uchun CPU'da real vaqtdan tez ishlaydigan modellar tanlandi. VoiceFixer va NeMo "muqobil, GPU mavjud bo'lganda" deb qisqa eslatiladi. Topshiriqdagi tarjima talabi (o'zbek ↔ 12 til) NLLB-200 ni, video sifati talabi esa FastDVDnet ni qo'shishni asoslaydi.

## Har bir modelni tadqiq qilish sxemasi (2.1)

1. **Vazifa va kelib chiqishi** — kim, qachon, qaysi maqolada.
2. **Matematik asoslari** — raqamlangan formulalar, har bir belgi izohlangan:
   - STFT: X(k,m) = Σ x(n)·w(n − mR)·e^{−j2πkn/N}
   - DeepFilterNet3: ERB-gain va deep filtering Y(k,m) = Σ_{i=0}^{N} C(k,i,m)·X(k, m − i + l)
   - Whisper: log-Mel spektrogramma, attention softmax(QKᵀ/√d_k)·V, cross-entropy
   - Pyannote: powerset segmentatsiya, speaker embedding, kosinus o'xshashlik, aglomerativ klasterlash
   - NLLB-200: Transformer encoder-decoder, Mixture-of-Experts gating
   - FastDVDnet: ikki bosqichli U-Net, shovqin xaritasi kiritmasi
   - FFmpeg: resampling, LUFS normalizatsiya (ITU-R BS.1770)
   - INT8 kvantlash: q = round(x/s) + z
3. **Ishlash algoritmi** bosqichma-bosqich.
4. **Tarkibidagi algoritmlar va bloklar** — qatlamlar, parametrlar, kadr uzunligi, chastota.
5. **Afzallik va cheklovlar**, CPU/RAM talablari.
6. **Tizimdagi o'rni** va tanlanish sababi.

Raqamlar faqat asl maqola yoki rasmiy repozitoriydan; shubha bo'lsa WebSearch bilan tekshiring. To'qima raqam yoki manba yozilmaydi.

## Fine-tuning (ilmiy yangilik)

- **DeepFilterNet3:** o'zbek nutqi (Common Voice uz, USC) + topshiriqdagi shovqin turlari (shamol, mashina, konditsioner, fon, hayvon, idish-tovoq; DEMAND, MUSAN, DNS Challenge); SNR bo'yicha aralashtirish y = s + α·n, α = sqrt(P_s / (P_n·10^{SNR/10})); multi-resolution spektral yo'qotish; PESQ, STOI, SI-SDR, DNSMOS.
- **Whisper large-v3:** Common Voice uz, FLEURS uz_uz, USC; LoRA W = W₀ + B·A; cross-entropy; WER, CER; whisper.cpp uchun GGUF ga o'tkazish va kvantlash.

Eksperiment natijalari faqat haqiqiy o'qitishdan olinadi; hali o'tkazilmagan bo'lsa jadvalda "[натижа]" belgisi qoldiriladi.

## Matn uslubi

- **Til:** o'zbek tili, **kirill alifbosi** (I bob imlosiga mos: ҳ, қ, ғ, ў).
- **Uslub:** ilmiy, jonli, inson yozgandek: jumlalar uzunligi xilma-xil, mantiqiy bog'lovchilar, muallifning o'z tahlili va xulosasi. Shablon iboralar va quruq ro'yxatlardan qoching; asosiy fikr paragraf ichida tushuntiriladi.
- **Originallik:** manbadan so'zma-so'z ko'chirmang; g'oyani o'z so'zlaringiz bilan bayon qilib, havola bering.
- Atama birinchi uchraganda: o'zbekcha + qavsda inglizcha.
- Yangi qisqartmalar (ERB, LoRA, WER, CER, DER, NLLB, MoE, GGUF, ONNX, JWT, RBAC, mTLS, HA, DR, LUFS, RTF, VM, NUMA) "Асосий қисқартма сўзлар" ro'yxatiga qo'shiladi.

## Raqamlash davomiyligi

- I bob 9-rasm va 2-jadval bilan tugagan: II bob **10-расм**, **3-жадвал** dan boshlanadi.
- Formulalar: (2.1), (2.2)…; (3.1)…
- Adabiyotlar [18] dan davom etadi.

## Adabiyotlar

- Asosan **rus tilidagi adabiyotlar** va eng sifatli **10 ta asosiy manba** (asl maqolalar: DeepFilterNet, Whisper, Pyannote, NLLB, FastDVDnet; texnologiyalar bo'yicha rasmiy hujjatlar).
- Rus tilidagi namunalar (nashr ma'lumotini tekshiring): Сергиенко А.Б. «Цифровая обработка сигналов»; Гудфеллоу Я. и др. «Глубокое обучение» (ДМК Пресс, 2018); Николенко С. и др. «Глубокое обучение» (Питер, 2018); Рабинер Л.Р., Шафер Р.В. «Цифровая обработка речевых сигналов»; Хайкин С. «Нейронные сети: полный курс»; Айфичер Э., Джервис Б. «Цифровая обработка сигналов».
- Rasmiylashtirish: ГОСТ Р 7.0.5–2008 uslubi.
- Har bir manba haqiqiy va tekshirilgan bo'lishi shart.

## Sahifa ostidagi izohlar

Foydalanilgan adabiyot haqida belgi **varaq oxirida**: matnda [N] va sahifa ostida haqiqiy Word footnote (muallif, nomi, yili, sahifa).

## Format (.docx)

Avval `docx` skillining SKILL.md faylini o'qing.
- **Times New Roman, 14 pt**; satr oralig'i 1,5; abzats 1,25 sm; eni bo'yicha tekislash.
- Hoshiyalar (boshqacha aytilmasa): chap 30, o'ng 15, yuqori/pastki 20 mm.
- Footnote: TNR 10–12 pt.
- Bob sarlavhasi bosh harflarda, markazda; har bob yangi sahifadan.
- Rasm osti: *10-расм. Номи*; jadval ustida o'ngda: *3-жадвал*.
- Formulalar Word tenglama (OMML), o'ngda raqami.
- Sahifa raqami pastda markazda.

## Bob tuzilishi

- Har bob qisqa kirish paragrafidan boshlanadi.
- Oxirida **"…-Боб бўйича хулосалар"** — 5–8 ta raqamlangan, aniq natijali band.

## Ish tartibi

1. I-БОБ.docx ni o'qib, uslub, atama va raqamlashni aniqlang.
2. Tizim skillidan joriy arxitektura qarorlarini oling.
3. Manbalarni WebSearch bilan tekshiring.
4. Avval bo'lim rejasini foydalanuvchiga ko'rsating.
5. Bo'limma-bo'lim yozing.
6. .docx yig'ing, PDF/rasmga aylantirib vizual tekshiring.
7. SendUserFile bilan yuboring.
