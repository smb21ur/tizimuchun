# Eksperiment, sinov va baholash (IV bob uchun)

## Asosiy tadqiqot savollari
1. Fine-tuning qilingan DeepFilterNet3 asl modelga nisbatan shovqin sinflari va SNR darajalari bo'yicha qanchalik yaxshilanadi?
2. Oldindan shovqin tozalash Whisper large-v3 (asl va fine-tuning qilingan) WER/CER ga hamda pyannote.audio DER ga qanday ta'sir qiladi?
3. Gipoteza: int8 kvantlash va strukturali pruning bilan o'rta darajadagi kompyuterda real vaqt tezligiga (RTF ≤ 1) sifat sezilarli tushmasdan erishish mumkinmi?
4. Tizim texnik topshiriqdagi talablarga (SNR yaxshilanishi, 10 GB fayl, batch, 8+ suhbatdosh) javob beradimi?

## Tajriba dizayni
- Uchta holat: toza audio, sun'iy shovqin qo'shilgan audio (SNR: 0, 5, 10, 15 dB), tozalangan audio.
- Shovqin sinflari (texnik topshiriqdan): shamol, mashina, konditsioner, fon shovqini, hayvon ovozi, idish-tovoq shovqini. Har sinf bo'yicha alohida natija.
- Takrorlash: tasodifiy urug' (seed), bir nechta takrorlash, o'rtacha va standart og'ish. Ablyatsiya: modellar, pruning/kvantlash darajalari.
- O'qitish, validatsiya va test to'plamlari bir-biridan ajratilgan bo'lsin (ma'lumot oqib o'tishi bo'lmasin).

## Metrikalar
- Shovqin tozalash (audio): ΔSNR (dB), SI-SDR, PESQ, STOI, DNSMOS (referensiz). Formulalarini II bobda bering.
- Video: PSNR, SSIM (CRVD kabi to'plamlar), vizual misollar.
- ASR: WER, CER (o'zbek tili uchun CER muhim). Matn normallashtirish va alifbo qoidasi barcha tajribada bir xil.
- Tarjima (agar modul kiritilsa, `tarjima-nllb.md`): spBLEU, chrF++ (FLORES to'plamida, har yo'nalish uchun), ixtiyoriy COMET; ASR → MT zanjirida xato ko'payishi.
- Diarizatsiya: DER, JER; 8 va undan ko'p suhbatdoshli yozuvlarda alohida; ovoz namunasi bo'yicha identifikatsiya aniqligi.
- Tizim: RTF, xotira sarfi, CPU yuklamasi, 10 GB fayl ishlov vaqti, batch o'tkazuvchanligi, serverni qayta yoqqandan keyin avtomatik tiklanish vaqti, zaxira serverga o'tish sinovi.

## Datasetlar (mavjudligi va litsenziyasini tekshirib kiriting)
DNS Challenge, MUSAN, VoiceBank-DEMAND (audio); CRVD, Set5 (rejada ko'rsatilgan; Set5 haqidagi eslatma `dissertatsiya-tuzilmasi.md` da); LibriSpeech, Common Voice (uz), FLEURS (uz) (ASR); AMI, VoxConverse yoki shu kabi ko'p suhbatdoshli to'plamlar (diarizatsiya). Har datasetning hajmi, tili, litsenziyasi va qanday ishlatilgani jadvalda ko'rsatilsin.

## Mavjud tizimlar bilan taqqoslash (4.2)
Taqqoslash ob'ektlari: RNNoise, DeepFilterNet (asl), fine-tuning qilingan DeepFilterNet3, tanlangan boshqa ochiq modellar; tijorat yoki mashhur vositalar faqat ularni haqiqatan sinab ko'rish mumkin bo'lsa. Adolatli taqqoslash: bir xil test to'plami, bir xil qurilma, bir xil metrikalar. Boshqa mualliflarning raqamlarini ko'chirsangiz, manbasini va test sharoiti farqini yozing.

## Sinov turlari (4.1)
Funksional (har bir talab bo'yicha o'tdi/o'tmadi jadvali, texnik topshiriqdagi 14 band), yuklama (ko'p foydalanuvchi, batch), ishonchlilik (tok o'chishi simulyatsiyasi, jarayonni majburan to'xtatish, qayta yoqish), xavfsizlik (login/parol, noto'g'ri urinishlar, audit jurnali), offline tekshiruv (tarmoqsiz muhitda to'liq ishlashi).

## Natijalarni yozish
Faqat haqiqiy o'lchangan raqamlar. Jadval va grafiklar skriptdan avtomatik chiqsin (qayta ishlab chiqarish uchun). Grafik yaratishdan oldin `dataviz` skill'ini (agar mavjud bo'lsa) ko'rib chiqing. Har natijadan keyin qisqa izoh va cheklovlar: nima uchun shunday chiqdi, qayerda model yomon ishladi.
