# Ko'p tilli tarjima moduli (NLLB-200) va stenogramma Word eksporti

**Holati: TAKLIF. Texnik topshiriqning 14 talabida va tasdiqlangan rejada yo'q.** Ilmiy rahbar Рахимов А.З. bilan kelishilmaguncha dissertatsiyaga "qo'shimcha modul" sifatida yozing va asosiy talab sifatida ko'rsatmang. Kelishilgach, bu belgini olib tashlang.

## Maqsad
1. Suhbat matnga aylantirilgach (Whisper), natija Word (.docx) faylida stenogramma sifatida beriladi: spiker, vaqt belgisi, matn.
2. Matn yoki yuklangan Word fayl quyidagi tillar va o'zbek tili orasida **ikki yo'nalishda** tarjima qilinadi: qozoq, qirg'iz, tojik, turkman, afg'on tillari (**pushtu ham, dari ham** — foydalanuvchi tasdiqlagan, ikkalasi alohida til sifatida), rus, ingliz, xitoy, turk, nemis, fransuz. Jami 12 til (afg'on ikki til hisobida).
3. Hammasi offline: ishlash vaqtida tarmoqqa chiqish yo'q (tekshiring).

## Tanlangan model: NLLB-200 (Meta, "No Language Left Behind")
Tanlov asoslari (2026-yil oktabr, qidiruv natijalari):
- 200 til, jumladan yuqoridagi tillar va o'zbek (FLORES-200 til kodlari, masalan, `uzn_Latn`).
- Variantlar: distilled 600M, distilled 1.3B va 3.3B. Server 256 GB RAM li CPU serverdir, 3.3B int8 sig'adi. Tezlik/sifat muvozanatini o'z qurilmada o'lchab tanlang.
- CPU inferensi: CTranslate2 int8 kvantlash (taxminan 2-4 marta tez va kam xotira).
- Taqqoslash nomzodi: MADLAD-400-3B (400 til, lokal ishga tushadi). Eng yaxshisini xotiradan emas, o'lchovdan tanlang.

## Cheklovlar (dissertatsiyada ochiq yozing)
- NLLB tadqiqot modeli, ishlab chiqarish uchun mo'ljallanmagan, tarjimalar rasmiy (sertifikatlangan) tarjima o'rnini bosmaydi. Hujjatda "mashina tarjimasi, tekshirish talab qilinadi" belgisi bo'lsin.
- O'zbek tilida xatolar bor (noto'g'ri tarjima, tarjima qilinmay qolgan bo'laklar; Princeton, 2026). Sifatni o'z o'lchovingiz bilan ko'rsating.
- Litsenziya: NLLB vaznlari CC-BY-NC 4.0 (notijorat). Tijorat topshirish rejalashtirilsa, litsenziyani asl manbadan tekshiring va muqobil (masalan, MADLAD) litsenziyasini ham.
- Yozuv: NLLB o'zbekchani lotinda beradi. Dissertatsiya kirillda, shuning uchun lotin ↔ kirill konvertori (qoidaga asoslangan) qo'shing va sozlamada yozuvni tanlatting. Konvertor xatolarini ham sinang.
- Afg'on tillari: pushtu (pbt_Arab) va dari (prs_Arab) alohida kodlar, ikkalasi ham modulga kiritiladi (klientda ikki alohida til sifatida). Kodlarni rasmiy ro'yxatdan tekshiring. Har biri uchun sifatni alohida o'lchang, chunki ularning resursi va sifati turlicha bo'lishi mumkin. Whisper'ning pushtu va dari uchun nutqni tanish sifati ham alohida tekshiriladi. Janubiy o'zbek (arab yozuvli, Afg'oniston) NLLB'da alohida til emas. Buning uchun "Lutfiy" (NLLB-600M asosida fine-tuning) bor, ishlatsangiz manbasini tekshirib havola bering.
- Past resursli yo'nalishlarda (masalan, turkman ↔ o'zbek) to'g'ridan-to'g'ri tarjima yomon bo'lsa, ingliz tili orqali (pivot) variantni sinab, natijani taqqoslang.

## Tizimga integratsiya (2.2 va 3.1 uchun)
Ovoz → (tozalash) → diarizatsiya → Whisper (til avtomatik aniqlanadi, original matn) → jumlalarga bo'lish → NLLB (CTranslate2, int8) → (kerak bo'lsa lotin ↔ kirill) → python-docx bilan .docx.
- Word fayl tuzilmasi: sarlavha, fayl ma'lumoti, jadval (vaqt, spiker, original, tarjima).
- Yuklangan .docx tarjimasi: paragraflar va jadval kataklarini o'qib, shrift/sarlavha/jadval formatini saqlagan holda matnni almashtirish; uzun matnni jumlalarga bo'lib tarjima qilish.
- Server tomonida alohida navbat (Celery yoki shunga o'xshash) va "Translation" xizmati; klientda til tanlash (manba/maqsad) va "Tarjima" tugmasi.

## Baholash (IV bob uchun, `eksperiment-va-baholash.md` ga qarang)
FLORES-200 / FLORES+ to'plamida spBLEU va chrF++ (har yo'nalish uchun), ixtiyoriy COMET (o'zbek uchun moslangan variantni manbadan tekshiring), tezlik (so'z/soniya, RTF), xotira. ASR → MT zanjirida xato ko'payishini (Whisper xatosi tarjimaga ta'siri) alohida o'lchang.

## Tadqiq ro'yxati (II bob uchun, manbadan tekshirib yozing)
NLLB Team (2022) maqolasi va rasmiy repozitoriy: arxitektura (encoder-decoder Transformer, sparsely gated mixture-of-experts), distillation, SentencePiece tokenizatori, til tegi (target prefix) bilan dekodlash, beam search, o'qitish ma'lumotlari, FLORES-200 va metrikalar. Formulalar va raqamlarni xotiradan yozmang.
