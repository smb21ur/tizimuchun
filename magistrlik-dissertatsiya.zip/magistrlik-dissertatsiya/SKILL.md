---
name: magistrlik-dissertatsiya
description: Saidov M.B. ning magistrlik dissertatsiyasi (Offline rejimda sun'iy intellekt asosida audio-video ma'lumotlarni shovqindan tozalash dasturiy ta'minoti, DeepFilterNet, pyannote.audio, Whisper large-v3, FastDVDnet) bo'yicha tadqiqot, adabiyotlar, dastur va eksperimentlar, boblarni o'zbek tilida kirill alifbosida yozish, DeepFilterNet3 va Whisper fine-tuning maqolalari va Word (.docx) rasmiylashtirish kerak bo'lganda ishlating.
---

# Magistrlik dissertatsiyasi: offline AI asosida audio-video shovqin tozalash dasturiy ta'minoti

## Loyiha pasporti
- **Mavzu (aynan shu shaklda):** «Offline режимда, сунъий интелект асосида ишлайдиган аудио – видео маълумотларни шовқиндан тозалаш дастурий таъминоти ишлаб чиқиш»
- **Muallif:** Саидов Маримбой Бахтиёрович. **Ilmiy rahbar:** Рахимов А.З. **Mutaxassislik:** 5А330302 – Ахборот хавфсизлиги (тармоқлар бўйича). **Joy, yil:** Нурафшон, 2026.
- **Dissertatsiya matni tili va yozuvi: o'zbek tili, KIRILL alifbosi.** Foydalanuvchi bilan suhbat lotin alifbosida bo'lishi mumkin, lekin dissertatsiya matni (boblar, annotatsiya, xulosa, jadval va rasm sarlavhalari) faqat kirillda yoziladi. Ingliz atamalarini lotinda qavs ichida bering (masalan, «диаризация (speaker diarization)»).
- **Boshlash nuqtasi: II bob** (2.1 matematik asoslar, 2.2 tizim arxitekturasi va algoritm). Foydalanuvchi aniq shuni so'ragan.
- **Shrift talabi (tasdiqlangan):** Times New Roman, 14.
- **Ikki maqola ham yoziladi:** (1) DeepFilterNet3 fine-tuning, (2) Whisper large-v3 fine-tuning.

## Manba hujjatlar (ma'lumotnomalar, kerak bo'lganda o'qing)
| Fayl | Nima uchun |
|------|-----------|
| `references/dissertatsiya-tuzilmasi.md` | Tasdiqlangan reja: titul, boblar va paragraf sarlavhalari (kirillda), Kirish elementlari, vazifalar, gipoteza, rejadagi nuqsonlar |
| `references/texnik-topshiriq.md` | Texnik topshiriqdagi 14 talab, server va klient texnik vositalari, SNR talabini aniqlashtirish |
| `references/modellar-tadqiqot.md` | Modellarni chuqur tadqiq qilish ro'yxati (matematik asos, algoritm qadamlari, ichki algoritmlar) |
| `references/finetuning-va-maqolalar.md` | Fine-tuning rejasi (ilmiy yangilik) va ikki maqola tuzilmasi |
| `references/eksperiment-va-baholash.md` | Tajriba dizayni, metrikalar, datasetlar, sinov turlari, taqqoslash |
| `references/adabiyotlar.md` | Adabiyot talablari (asosan rus tilida, eng yaxshi 10 ta), havola formati, tekshiruv qoidalari |

Mavzuga oid har ishni boshlashdan oldin tegishli ma'lumotnomani o'qing. Boshqa hujjat (masalan, universitet shabloni) berilsa, u ushbu fayllardan ustun turadi va qarama-qarshilik haqida foydalanuvchiga ayting.

## Ish tartibi
Standart tartib (foydalanuvchi o'zgartirishi mumkin): **II bob → III bob → IV bob → I bob → Kirish, Annotatsiya, Xulosa → Adabiyotlar va Ilovalar**, ikki maqola esa fine-tuning natijalari tayyor bo'lgach. Sabab: avval model va tizimning mohiyati, so'ng sinov natijalari yoziladi, kirish va xulosa oxirida to'liq mos tushadi.

Boshlashdan oldin kerak bo'lsa, qisqa so'rang (bir xabarda, ko'pi bilan to'rtta savol): GPU yoki bulut o'qitish uchun bormi, havolalar standarti va institut shabloni, "eng yaxshi 10 ta adabiyot" qanday tushunilishi (`adabiyotlar.md`), maqolalar tili va jurnali, texnik topshiriqdagi muddatlar. Javobsiz qolgan masalada eng oqilona variantni tanlab, qaysi variantni olganingizni aytib, davom eting.

### Bob yozish tartibi (har bob uchun)
1. `dissertatsiya-tuzilmasi.md` dan shu bobning aniq sarlavhalarini oling (kirill, o'zgartirmang).
2. Kerakli manbalarni WebSearch/WebFetch bilan topib, asl maqola va rasmiy hujjatdan tekshiring.
3. Bob rejasini (paragraflar, rasm/jadval/formulalar ro'yxati) qisqa ko'rsating, so'ng matnni yozing. Bobni bitta-bitta yozib, ko'rsatib, fikr olib, keyin davom eting.
4. Formulalar raqamlangan, belgilari izohlangan. Rasm va jadvallar raqamlangan sarlavhali. Blok-sxema, arxitektura va ketma-ketlik diagrammalarini haqiqiy mexanizmni ko'rsatadigan qilib chizing.
5. Har bobda matn hajmi va chuqurlik tadqiqot talabiga mos: modellar uchun batafsil matematika va algoritm qadamlari (II bob), mazmunsiz "suv" yozmang.

## Dasturiy ta'minot va eksperimentlar
- Kodni fayl sifatida yozing, ishga tushirib tekshiring, `requirements.txt` va seed bilan takrorlanuvchan qiling. Tekshirilmagan narsani "ishlaydi" demang.
- Ish muhiti tarmoqqa cheklangan va GPU bo'lmasligi mumkin. Model yuklab bo'lmasa yoki resurs yetmasa, ochiq ayting va foydalanuvchi o'z kompyuterida yoki bulutda ishga tushiradigan tayyor skript va yo'riqnoma bering.
- pyannote modellari Hugging Face tokeni va foydalanish shartlarini qabul qilishni talab qiladi. Buni oldindan ayting.
- Offline talab: ishlash vaqtida tarmoqqa chiqish bo'lmasligini tekshiring.

## Yozuv va rasmiylashtirish
- Ilmiy, aniq, o'zbek adabiy tili, kirill alifbosi. Bir atama butun matnda bir xil. Imlo variantlarini (интелект/интеллект) bitta qilib tanlang.
- Word hujjat: avval `/mnt/skills/public/docx/SKILL.md` ni o'qing. Tasdiqlangan talab faqat Times New Roman 14. Qolgan parametrlar (A4, qator oralig'i 1,5, chetlar chap 30 / o'ng 15 / yuqori va pastki 20 mm, sahifa raqami, avtomatik mundarija, sarlavha uslublari) institut talabi ma'lum bo'lmaguncha ehtiyotiy standart sifatida qo'llanadi va buni foydalanuvchiga ayting.
- Kirill matnli docx uchun kirill harflari to'g'ri ko'rinishini va TNR shrifti ishlatilganini tayyor faylni ochib tekshiring.

## Qat'iy qoidalar
- Manba, statistika, formula, model xususiyati va eksperiment natijasini hech qachon to'qimang. Natija bo'lmasa `[НАТИЖА КУТИЛМОҚДА]` deb belgilang.
- Namunaviy rejadagi nuqsonlar (to'ldirilmagan «ҒҒҒ», tekshirilmagan 82 foiz, buzilgan jumlalar) ko'chirilmaydi (`dissertatsiya-tuzilmasi.md`).
- Plagiat yo'q: o'zga matnni ko'chirmang, qayta bayon qiling va havola bering.
- Dissertatsiya va maqolalar muallifning o'z ishi: qoralama, tadqiqot va tahlilni Claude beradi, mazmun va xulosalarni muallif tekshirib o'zlashtiradi. Buni qisqa eslatib qo'ying.
- Rejaga o'zgartirish (masalan, Whisper modulini qo'shish) ilmiy rahbar bilan kelishiladi, foydalanuvchiga shuni eslating.
- Shaxsiy ovoz yozuvlari bilan ishlaganda ruxsat va maxfiylikni eslating.
- Noaniq va natijasi qimmat narsada taxmin qilmasdan so'rang.

## Yakuniy javob formati
Bosqich tugagach: nima tayyor bo'ldi (1-2 jumla), fayl, keyingi mantiqiy qadam. Qadamlarni sanab o'tirmang.
