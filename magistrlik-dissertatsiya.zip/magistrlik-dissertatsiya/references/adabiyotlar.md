# Adabiyotlar bilan ishlash qoidalari

## Talab (dissertatsiyaga_talablar.docx)
"Asosan rus adabiyotlari va eng yaxshi 10 ta adabiyotdan foydalan." Ikki xil o'qilishi mumkin:
- ro'yxatning asosiy qismi rus tilidagi adabiyotlar bo'lsin va unga qo'shimcha ravishda eng yaxshi (eng muhim) 10 ta manba kiritilsin;
- jami eng yaxshi 10 ta asosiy manbaga tayaning.
Birinchi suhbatda foydalanuvchidan aniqlang. Aniqlanmaguncha: rus tilidagi manbalarga ustunlik bering va ularga qo'shimcha ravishda 10 ta eng muhim manbani (odatda asl xorijiy maqolalar) belgilab, ularni alohida ajratib ko'rsating.

## Rus tilidagi manbalarni qidirish
Rus tilidagi darsliklar, monografiyalar, ilmiy maqolalar va tarjima asarlarni qidiring: raqamli signalga ishlov berish, nutqni qayta ishlash va tanish, shovqin bostirish, chuqur o'rganish, tasvir va videoga ishlov berish. Qidiruv manbalari: elibrary.ru, CyberLeninka, rasmiy nashriyot sahifalari, kutubxona katalogi. Xorijiy asosiy maqolalarning rus tilidagi tarjimasi yoki rus tilidagi sharhi bo'lsa, shuni ham ko'rsating.
Nomzod yo'nalishlar (har birini haqiqiy mavjudligini tekshirib, to'liq bibliografik ma'lumot bilan kiriting): Rabiner va Gold tarjima asari "Теория и применение цифровой обработки сигналов", Goodfellow va boshq. "Глубокое обучение" tarjimasi (ДМК Пресс), Sergienko "Цифровая обработка сигналов", Gonzalez va Woods "Цифровая обработка изображений" tarjimasi. Bu nomlar faqat qidiruv uchun boshlang'ich nuqta, ularni tekshirmasdan ro'yxatga qo'shmang.

## Asosiy xorijiy manbalar (asl maqola sifatida tekshiring)
DeepFilterNet (3 ta maqola), RNNoise (Valin), pyannote.audio (Bredin va boshq.; Plaquet va Bredin), Whisper (Radford va boshq.), FastDVDnet (Tassano va boshq.), BasicVSR++ (Chan va boshq.), FullSubNet (Hao va boshq.), Loizou "Speech Enhancement: Theory and Practice", Proakis va Manolakis "Digital Signal Processing", DNS Challenge, VoiceBank-DEMAND, MUSAN, CRVD maqolalari.

## Havolalarni rasmiylashtirish
- Matnda raqamli havola, sahifa bilan: `[5, б.15]`, rasmiy ro'yxatdagi tartib raqamiga mos. Havola matn ichida bitta formatda bo'lsin (rejadagi aralash va ichiga yopishtirilgan to'liq matnli havolalarni takrorlamang).
- Ro'yxatda: muallif(lar), sarlavha, nashr (jurnal/nashriyot), yil, tom/son, sahifalar, DOI yoki URL. Davlat standarti yoki institut qoidasi aniq bo'lsa, shunga amal qiling; bo'lmasa, foydalanuvchidan so'rang.
- Ro'yxat matnda birinchi uchragan tartibda raqamlanadi (yoki institut talab qilgan tartibda).

## Tekshirish va halollik
- Har bir manbani qidiruv bilan haqiqatan topib, muallif, yil, sarlavha, nashrni asl sahifadan tekshiring. Topilmagan manbani kiritmang yoki "tekshirilmagan" deb belgilab, foydalanuvchiga ayting.
- Manbada yo'q raqam, foiz yoki tasdiqni yozmang. Statistikani manba bilan keltiring.
- Matnni ko'chirmang: o'z so'zlaringiz bilan qayta bayon qiling, qisqa iboralarni qo'shtirnoqda va havola bilan bering. Plagiat tekshiruvidan o'tadigan original matn yozing.
- Natija: manbalar jadvali (muallif, yil, usul, asosiy xulosa, qaysi bo'limda ishlatiladi, havola holati: tekshirildi/tekshirilmagan).
