# Dissertatsiya tuzilmasi (tasdiqlangan namunaviy reja asosida)

Manba: Saidov_M1.docx. Reja institut ilmiy ishlar bo'yicha o'rinbosari tomonidan 2026-yil mart oyida tasdiqlangan. Rejaga o'zgartirish faqat ilmiy rahbar bilan kelishib kiritiladi (rejaning o'zida "zarur hollarda o'zgartirish va qo'shimchalar kiritilishi mumkin" deyilgan).

## Titul varag'i ma'lumotlari
- Institut: Криптология, ахборот хавфсизлиги ва инновацион технологиялар институти
- Muallif: САИДОВ МАРИМБОЙ БАХТИЁРОВИЧ (1-kurs tinglovchisi)
- Mutaxassislik: 5А330302 – Ахборот хавфсизлиги (тармоқлар бўйича)
- Daraja: Магистр, "Диссертация", qo'lyozma huquqida
- Ilmiy rahbar: Рахимов А.З.
- Joy va yil: Нурафшон, 2026 й.
- Mavzu (aynan shu shaklda): «Offline режимда, сунъий интелект асосида ишлайдиган аудио – видео маълумотларни шовқиндан тозалаш дастурий таъминоти ишлаб чиқиш»

## Umumiy tartib
Титул → Аннотация → Мундарижа → Кириш → I–IV боб → Хулоса → Фойдаланилган адабиётлар рўйхати → Иловалар.

## Bo'limlar (sarlavhalar aynan shunday)

**Кириш**

**I БОБ.** АУДИО ВА ВИДЕО МАЪЛУМОТЛАРДА ШОВҚИНЛАР, УЛАРНИ БАРТАРАФ ЭТИШ УСУЛЛАРИ, МОДЕЛЛАРИ ВА АЛГОРИТМЛАРИ БЎЙИЧА ЧЕТ ЭЛ ТАЖРИБАСИ ТАҲЛИЛИ
- 1.1. Сигналлар ва шовқин турлари, аудио сигналлар ва видео файллардаги шовқинларни анъаний ва сунъий интелект асосида тозалаш усуллари тадқиқи.
- 1.2. Аудио сигналлар ва видео файлларни шовқинлардан тозалаш, сухбатдошларни овозини аниқлаш ва ажратиш бўйича чет эл тажрибаси таҳлили.

**II БОБ.** АУДИО ВА ВИДЕО МАЪЛУМОТЛАРНИ OFF-LINE СУНЪИЙ ИНТЕЛЛЕКТ АСОСИДА ШОВҚИНДАН ТОЗАЛАШ, УЛАРДАГИ СУХБАТДОШЛАРНИ АЖРАТИШ МОДЕЛЛАРИ ВА АЛГОРИТМЛАРИ ДАСТУРИЙ КУТУБХОНАЛАРНИНГ МАТЕМАТИК АСОСЛАРИНИ ТАДҚИҚ ЭТИШ
- 2.1. Сигналларни шовқиндан тозалаш ҳамда сухбатдошларни ажратувчи моделлар ва алгоритмлари дастурий кутубхоналарининг математик асосларини тадқиқ қилиш.
- 2.2. Сунъий интеллект моделларини қўллаш орқали аудио, видео сигналларни шовқиндан тозалаш ҳамда улардаги сухбатдошларни ажратувчи дастурий тизим архитектурасини лойиҳалаш ва алгоритмини ишлаб чиқиш.

**III БОБ.** СУНЪИЙ ИНТЕЛЛЕКТ АСОСИДА АУДИО-ВИДЕОЛАРНИ ШОВҚИНДАН ТОЗАЛАШ ТИЗИМНИ ИШЛАБ ЧИҚИШ
- 3.1. Тизимнинг сервер қисми учун модулларини ишлаб чиқиш ва сунъий интеллект моделларига боғлаш.
- 3.2. Тизимнинг фойдаланувчи қисми дастурини ишлаб чиқиш.

**IV БОБ.** АУДИО ВА ВИДЕО МАЪЛУМОТЛАРНИ OFF-LINE СУНЪИЙ ИНТЕЛЛЕКТ АСОСИДА ИШЛОВЧИ ТИЗИМНИ АМАЛИЙ ЖОРИЙ ЭТИШ ВА НАТИЖАЛАР ТАҲЛИЛИ
- 4.1. Тизимни амалий ишга тушириш ва синовдан ўтказиш.
- 4.2. Тизим самарадорлигини баҳолаш ва мавжуд тизимлар билан таққослаб, натижаларини таҳлил қилиш.

**Хулоса · Фойдаланилган адабиётлар рўйхати · Иловалар**

Eslatma: namunaviy rejada "тизимни" va "сунъий интелект/интеллект" kabi imlo xilma-xilligi bor. Dissertatsiyada bitta imloni tanlang va bir xil qo'llang.

## Bobga yuklangan mazmun
- **I bob:** signal va shovqin turlari (stasionar/nostasionar, additiv, impulsli, reverberatsiya, optik/sensor shovqini videoda), klassik usullar (Wiener filtri, spektral ayirish, adaptiv filtrlar; videoda Non-Local Means, BM3D), chuqur o'rganish usullari (CNN, RNN, Transformer, GAN), diarizatsiya bo'yicha xorij tajribasi. Qiyosiy jadval: usul, yil, arxitektura, offline imkoniyat, sifat ko'rsatkichi.
- **II bob:** tanlangan modellarning matematik asoslari va algoritm qadamlari (batafsil: `modellar-tadqiqot.md`). 2.2 da tizim arxitekturasi va algoritm blok-sxemasi.
- **III bob:** server va klient dasturini yaratish (talablar: `texnik-topshiriq.md`).
- **IV bob:** sinov, metrikalar, mavjud tizimlar bilan taqqoslash, gipotezani tekshirish (`eksperiment-va-baholash.md`). Fine-tuning natijalari (ilmiy yangilik) shu bobda yoki alohida paragrafda beriladi (`finetuning-va-maqolalar.md`).

## Kirish bo'limi elementlari (tasdiqlangan rejadagi tartibda)
1. Dolzarblik (offline: maxfiylik, internet trafigiga bog'lanmaslik; server-klient: xarajat tejash; diarizatsiya modulining qo'shilishi).
2. Ilmiy ishning maqsadi: offline, katta hajmli audio-video fayllarni professional darajada tozalash, 8 va undan ortiq suhbatdoshni ajratish imkonini beruvchi server-klient dasturiy ta'minot majmuasini ishlab chiqish.
3. Tadqiqot vazifalari (9 ta):
   1. Adabiyotlarni tizimli tahlil qilish (shovqin tozalash, speaker diarization, signalga ishlov berish, chuqur o'rganish vositalari).
   2. Mavjud tizimlarni (U-Net, RNNoise, SEGAN, DeepFilterNet, BasicVSR++ va h.k.) offline sharoitda qiyosiy tahlil qilish.
   3. Yengil va samarali neyron tarmoq arxitekturasini tanlash, real vaqt uchun tayyorlash va tizimga moslashtirish.
   4. Videodan audioni ajratish, tozalash va videoga qayta qo'shish algoritmlari va dasturini tahlil qilish hamda ishlab chiqish.
   5. Zamonaviy denoising modellarini (CNN, RNN, Transformer, GAN) qiyosiy tahlil qilish.
   6. O'qitish uchun sifatli audio-video dataset shakllantirish va gibrid o'qitish usullarini qo'llash.
   7. Audio va video tozalash modullarini birlashtiruvchi grafik interfeysli yaxlit dasturiy ta'minotni JAVA, Web, Python asosida ishlab chiqish.
   8. Standart datasetlarda (DNS Challenge, MUSAN, VoiceBank-DEMAND, CRVD, Set5) eksperimental sinov va baholash.
   9. Natijalar asosida tavsiyalar va xulosalar shakllantirish.
4. Tadqiqot obyekti: tashqi/ichki omillar (fon shovqini, interferensiya, optik shovqin) ta'sirida sifati buzilgan analog va raqamli audio signallar va video fayllar.
5. Tadqiqot predmeti: offline AI usullari bilan audio-video shovqin tozalash, signalni qayta tiklash jarayonlari, ularni amalga oshiruvchi algoritmlar, arxitektura va dasturiy-texnik yechimlar.
6. Muammoning o'rganilganlik darajasi: Wiener (1949), spektral ayirish (Boll, 1979; Berouti va boshq., 1979), Non-Local Means (Buades, 2005), BM3D (Dabov, 2007), RNNoise (Valin, 2018), FullSubNet (Hao, 2021), DeepFilterNet (Schröter, 2022), DnCNN, FFDNet, VNLnet, BasicVSR++. Har bir yil va muallifni asl manbadan tekshirib yozing.
7. Gipoteza: offline, lokal tarmoq uchun optimallashtirilgan AI modellar int8 kvantlash va strukturali pruning bilan birlashtirilsa, bulut infratuzilmasisiz o'rta darajadagi kompyuterlarda real vaqt tezligida yuqori sifatli shovqin bostirishga erishish mumkin. Gipoteza IV bobda raqamlar bilan tasdiqlanishi yoki rad etilishi shart.
8. Ilmiy yangilik: DeepFilterNet3 va Whisper large-v3 ni fine-tuning qilish (talablar hujjatiga muvofiq).
9. Amaliy ahamiyat, ishning tuzilishi.

## Namunaviy rejadagi nuqsonlar (ko'chirmang!)
- Kirishda "2025 yilda ҒҒҒ фоизини медиа ташкил қилган" qoldirilgan joy va "2024 yilda 82 foiz" statistikasi tekshirilmagan. Manba topilmasa, raqamni olib tashlang yoki umumiy ibora bilan almashtiring.
- I bobning boshida buzilgan jumla va aralash tildagi (lotin) havola matnlari bor. Ularni tozalab, havolani yagona formatda yozing.
- Ba'zi xorijiy ismlar noto'g'ri transliteratsiya qilingan (masalan, "Зҳанг"). Ismlarni yagona qoida bilan yozing (Zhang, Hao, Valin).
- "Speak Diarization" aslida "Speaker Diarization". Matnda to'g'ri atamani qo'llang, texnik topshiriqdagi shaklni faqat iqtibosda saqlang.
- Vazifalar ro'yxatida Whisper (nutqni matnga o'tkazish) yo'q, lekin talablar hujjatida Whisper large-v3 fine-tuning majburiy. Bu farqni ilmiy rahbarga ko'rsatib, rejaga Whisper modulini qo'shishni kelishing.
- Set5 bu super-resolution uchun 5 tasvirli to'plam. Video denoising uchun CRVD kabi video to'plamlar asosiy bo'lsin, Set5 ni ilmiy rahbar bilan aniqlashtiring.
