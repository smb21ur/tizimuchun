# Fine-tuning (ilmiy yangilik) va ikkita maqola

Talab (dissertatsiyaga_talablar.docx): ilmiy yangilik uchun **DeepFilterNet3** va **Whisper large-v3** ("openwhisper large3") ni qanday fine-tuning qilish mumkinligini albatta yoritish: qaysi datasetlarda o'qitiladi, qaysi matematik formulalar ishlatiladi va h.k. Shuningdek **2 ta maqola** yozish kerak:
1. DeepFilterNet3 ni fine-tuning qilish haqida;
2. Whisper large-v3 ni fine-tuning qilish haqida.

## Haqiqiylik qoidasi
Fine-tuning ilmiy yangilik sifatida ko'rsatilgan, ya'ni o'qitish **haqiqatan bajarilishi** kerak. Ishlamagan yoki hali o'tkazilmagan eksperiment uchun natija yozmang. Natija bo'lmagan joyga `[NATIJA KUTILMOQDA]` qo'ying. O'qitish uchun GPU kerak: avval foydalanuvchidan qanday GPU/bulut borligini so'rang. GPU bo'lmasa, to'liq ishlaydigan va qayta ishlab chiqariladigan o'qitish skriptlari, konfiguratsiya va aniq yo'riqnoma tayyorlang, natijalarni foydalanuvchi o'z muhitida olib keladi.

## A. DeepFilterNet3 ni fine-tuning qilish
Aniqlanadigan narsalar (rasmiy repozitoriy hujjati va maqoladan tekshiring):
- Maqsad: qaysi sohaga moslash (texnik topshiriqdagi shovqin sinflari: shamol, mashina, konditsioner, fon, hayvon ovozi, idish-tovoq; o'zbek tilidagi nutq; past sifatli mikrofon yozuvlari).
- Boshlang'ich nuqta: rasmiy oldindan o'qitilgan DeepFilterNet3 vaznlari.
- Ma'lumot tayyorlash: toza nutq to'plami, shovqin to'plami, RIR (xona impuls javoblari); repozitoriy kutadigan dataset formati va konfiguratsiya fayllarini hujjatdan oling; on-the-fly aralashtirish, SNR diapazoni.
- Yo'qotish funksiyalari va ularning formulalari (maqoladagi aniq ta'rif bilan), optimizator, o'qitish tezligi jadvali, epoxalar, batch hajmi.
- Fine-tuning strategiyasi: butun tarmoqni qayta o'qitish va qisman muzlatish (encoder/decoder) taqqoslash, "katastrofik unutish" ni nazorat qilish (original test to'plamida sifat tushmasligini tekshirish).
- Baholash: PESQ, STOI, SI-SDR, DNSMOS; fine-tuning dan oldin va keyin, har bir shovqin sinfi va SNR (masalan, 0/5/10/15 dB) bo'yicha jadval.
- Tezlik va xotira: RTF, int8 kvantlash va pruning ta'siri (gipoteza bilan bog'lanadi).

Dataset nomzodlari (mavjudligi va litsenziyasini tekshiring): DNS Challenge ma'lumotlari, VoiceBank-DEMAND, MUSAN, DEMAND, ESC-50 va UrbanSound8K yoki FSD50K (shamol, mashina, hayvon, maishiy tovushlar uchun), Common Voice va FLEURS (o'zbek nutqi), RIR to'plamlari.

## B. Whisper large-v3 ni fine-tuning qilish
Aniqlanadigan narsalar:
- Maqsad: o'zbek tili (va, ehtimol, shovqinli yoki telefon sifatli audio) uchun WER/CER ni pasaytirish.
- Boshlang'ich nuqta: `openai/whisper-large-v3` vaznlari (Hugging Face).
- Usullar: to'liq fine-tuning va parametr-tejamkor usullar (LoRA/PEFT, kvantlangan o'qitish) taqqoslash. 1.5 mlrd parametrli model uchun xotira talabini hisoblab ko'rsating.
- Ma'lumot: Common Voice (uz), FLEURS (uz), mavjud bo'lsa o'z yozuvlar. Audio 16 kHz, 30 s gacha bo'laklar, matnni normallashtirish.
- **Alifbo masalasi:** o'zbek tili uchun lotin va kirill yozuvi aralash uchraydi. Chiqish alifbosini bitta qilib belgilang (dissertatsiya kirillda bo'lsa ham, ASR chiqishi alifbosini ongli tanlang), matnlarni shu alifboga keltirish (transliteratsiya) qoidasini yozing va WER hisoblashda bir xil normallashtirishni qo'llang.
- O'qitish: token bo'yicha cross-entropy yo'qotishi (formula), AdamW, warmup, gradient accumulation, mixed precision (fp16/bf16), baholash chastotasi.
- Baholash: WER, CER (formulalar), fine-tuning dan oldin va keyin; toza va shovqinli (SNR darajalari bo'yicha) audioda; DeepFilterNet bilan oldindan tozalashning ASR sifatiga ta'siri (konveyer bo'yicha asosiy tadqiqot savoli).
- Joriy etish: faster-whisper/CTranslate2 ga o'tkazish, int8, CPU da tezlik (RTF) va sifat o'zgarishi.

## Maqolalar tuzilmasi (har biri uchun)
Qisqa annotatsiya (maqola tilida va ingliz tilida) → kalit so'zlar → Kirish → Adabiyot sharhi (qisqa) → Metodologiya (model, matematik asos, ma'lumot, o'qitish sozlamalari) → Eksperimentlar va natijalar (haqiqiy o'lchovlar) → Muhokama va cheklovlar → Xulosa → Adabiyotlar.
Savollar (boshida so'rang): maqola tili (o'zbek/rus/ingliz), nashr qilinadigan jurnal yoki konferensiya va uning shabloni, hajmi, hammualliflar (ilmiy rahbar).
Maqolalar dissertatsiyaning II va IV boblari bilan bir xil natijalarga tayansin, raqamlar mos tushsin.
