# Tanlangan AI modellarni chuqur tadqiq qilish (II bob uchun)

Talab (dissertatsiyaga_talablar.docx): tanlangan modellarning **matematik asoslari, ishlash algoritmi qaysi qadamlar bilan ishlashi, tarkibidagi barcha algoritmlar** batafsil yoritilsin.

## Ishlash qoidasi
Quyidagi ro'yxat faqat nimani qidirish kerakligini ko'rsatadi. Formulalar, o'lchamlar, giperparametrlar va arxitektura tafsilotlarini **asl maqola va rasmiy repozitoriydan** olib tekshiring (WebSearch/WebFetch). Xotiradan formula yoki raqam yozmang. Har bir formulani belgilar izohi bilan bering (o'lchamlar, indekslar), tartib raqamli yozing va manbaga havola qiling. Qaysi qism manbadan, qaysi biri o'z tushuntirishingiz ekanini ajrating.

Har model uchun uchta narsa shart: (a) matematik asos, (b) ishlash qadamlari (kirishdan chiqishgacha, blok-sxema bilan), (c) tarkibidagi algoritmlar va ularning vazifasi.

## 1. Umumiy signal asoslari (hamma model uchun)
- Diskretizatsiya, kvantlash, Nyquist teoremasi; additiv shovqin modeli y(t) = x(t) + n(t), reverberatsiya bilan (RIR bilan konvolyutsiya).
- STFT, oyna funksiyalari, hop o'lchami, spektrogramma; mel va ERB/Bark shkalalari; log-mel.
- SNR, SI-SDR, PESQ, STOI ta'riflari (formulalar bilan).
- Videoda: shovqin modellari (Gauss, Poisson-Gauss, raw sensor shovqini), PSNR/SSIM.

## 2. DeepFilterNet (asosiy model, DeepFilterNet3 ga e'tibor)
Manbalar: Schröter va boshq. DeepFilterNet (ICASSP 2022), DeepFilterNet2 (IWAENC 2022), DeepFilterNet3 (Interspeech 2023) va rasmiy GitHub repozitoriy.
Tadqiq qilinadigan elementlar:
- 48 kHz full-band ishlov, STFT parametrlari.
- Ikki bosqichli g'oya: ERB shkalasidagi spektral envelope kuchaytirish va **deep filtering** (kompleks spektrda ko'p kadrli FIR filtr koeffitsiyentlarini tarmoq bashorat qiladi). Deep filtering formulasini maqoladagi aniq belgilar bilan yozing.
- Arxitektura: encoder, ERB decoder, DF decoder, GRU/konvolyutsiya bloklari, kirish xususiyatlari (ERB va kompleks xususiyatlar), parametrlar soni va murakkablik.
- O'qitish: yo'qotish funksiyalari (ko'p o'lchamli spektral yo'qotish va boshqalar, aniq ta'rifini maqoladan oling), optimizator, o'qitish jadvali, ma'lumotni shovqin va RIR bilan "on-the-fly" aralashtirish, SNR diapazoni.
- Versiyalar o'rtasidagi farq (v1 → v2 → v3) va nima uchun yaxshilangani.
- Real vaqt va embedded imkoniyatlari (offline tezlik uchun muhim).

## 3. RNNoise
Manba: Valin (MMSP 2018) va rasmiy repozitoriy. Tadqiq: gibrid DSP + chuqur o'rganish, Bark shkalasidagi polosa kuchaytirishlari, pitch (asosiy chastota) filtri, GRU tarmog'i, VAD, xususiyatlar, yo'qotish. Tizimda uning o'rni (yengil birinchi bosqich yoki taqqoslash uchun) ni aniqlang.

## 4. FastDVDnet (video denoising)
Manba: Tassano, Delon, Veit (CVPR 2020) va repozitoriy. Tadqiq: aniq harakat baholashsiz ishlash, ketma-ket kadrlar oynasi, ikki bosqichli U-Net tipidagi bloklar, yo'qotish va o'qitish ma'lumoti, PSNR/SSIM natijalari, tezlik. Taqqoslash uchun BasicVSR++ (CVPR 2022), DnCNN, FFDNet, VNLnet.

## 5. pyannote.audio (speaker diarization)
Manbalar: Bredin va boshq. (ICASSP 2020), Plaquet va Bredin (Interspeech 2023, powerset yo'qotishi), rasmiy hujjat va Hugging Face model kartochkalari (versiyani tekshiring: 3.x yoki yangisi).
Tadqiq: pipeline bosqichlari (nutq faolligi/segmentatsiya, overlap, speaker embedding, klasterlash), segmentatsiya modeli arxitekturasi va yo'qotishi, embedding modeli, klasterlash algoritmi (aglomerativ), DER va uning tarkibi (xato turlari), speaker identifikatsiya (ovoz namunasini kosinus o'xshashlik bilan moslashtirish) matematikasi. 8 va undan ko'p suhbatdoshda cheklovlar va sozlamalar (min/max speakers).

## 6. Whisper large-v3 (ASR, fine-tuning ob'ekti)
Manbalar: Radford va boshq. (2022) "Robust Speech Recognition via Large-Scale Weak Supervision", OpenAI repozitoriysi, Hugging Face model kartochkasi (large-v3 haqida ma'lumotni shu yerdan tekshiring).
Tadqiq:
- Kirish: 16 kHz, log-mel spektrogramma (large-v3 dagi mel kanallar sonini manbadan tekshiring), 30 soniyalik oynalar.
- Encoder-decoder Transformer: konvolyutsion kirish qatlamlari, pozitsion kodlash, multi-head self-attention va cross-attention formulalari (softmax(QKᵀ/√d_k)V), qatlamlararo normalizatsiya, MLP bloklari, parametrlar soni.
- Maxsus tokenlar va ko'p vazifali format (til, transkripsiya/tarjima, vaqt belgilari), BPE tokenizator.
- Dekodlash: greedy/beam search, harorat zaxirasi, log-ehtimollik chegaralari.
- O'qitish: kuchsiz nazoratli katta hajmli ma'lumot, yo'qotish (token bo'yicha cross-entropy), WER/CER metrikalari formulalari (almashtirish, o'chirish, qo'shish).
- Offline va CPU da ishlatish: faster-whisper/CTranslate2, int8 kvantlash.

## 7. Qiyosiy tahlil uchun boshqa modellar
U-Net, SEGAN, FullSubNet, Demucs, GAN asosidagi usullar, Transformer asosidagi denoiserlar. Qiyosiy jadval ustunlari: arxitektura turi, kirish (vaqt/chastota sohasi), parametrlar soni, offline imkoniyati, real vaqt, ochiq litsenziya, e'lon qilingan metrikalar. Faqat manbada keltirilgan raqamlarni, manbasi bilan yozing.

## 8. Tizimga integratsiya algoritmi (2.2 uchun)
Videodan audioni ajratish → resample → bo'laklash → shovqin tozalash → (ixtiyoriy) diarizatsiya va ASR → natijani yig'ish (video oqimini o'zgartirmay, tozalangan audio bilan qayta ulash, sinxronlik). Psevdokod va blok-sxema bering.
