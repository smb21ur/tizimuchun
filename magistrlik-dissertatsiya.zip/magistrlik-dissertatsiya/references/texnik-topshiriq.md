# Texnik topshiriq (topshiriq.docx) bo'yicha dastur talablari

Mavzu: Off-line rejimda, sun'iy intellekt asosida ishlaydigan audio-video ma'lumotlarni shovqindan tozalash dasturiy ta'minoti.
Reja: (1) maqsad, (2) ishlab chiqish bosqichlari va muddatlari, (3) talablar, (5) xulosa.
Bosqichlar: texnik topshiriqni tasdiqlash, dasturni ishlab chiqish, testdan o'tkazish. Muddatlar hujjatda berilmagan, foydalanuvchidan so'rang.

## Tizim tarkibi
- **Server:** foydalanuvchi yuklagan ma'lumotlarga ishlov beradi va natijani qaytaradi.
- **Foydalanuvchi (klient):** operatorlarning ish joyi.

## Talablar (14 ta) va ularni amalga oshirish yo'nalishi

| № | Talab | Amalga oshirish eslatmasi |
|---|-------|---------------------------|
| 1 | Offline, AI asosida, katta hajmli audio-video fayllarni professional tozalash | Modellar lokal; ishlash vaqtida tarmoqqa chiqish yo'q (tekshiring) |
| 2 | Ikki qism: server va klient | Server API + klient ilova |
| 3 | Klient serverga login/parol bilan ulanadi | Autentifikatsiya, parollar xeshlanadi (bcrypt/argon2), sessiya/JWT |
| 4 | Server-klient aloqasi lokal tarmoqda | Internet talab qilinmaydi; TLS lokal sertifikat bilan |
| 5 | Uzluksiz ishlash; tok o'chishi, UPS tugashi, OT xatosidan keyin server qayta yoqilganda barcha ilovalar avtomatik ishga tushishi | systemd servislari yoki Docker `restart: always`, ishga tushish tartibi, to'xtab qolgan vazifalarni navbatdan tiklash |
| 6 | Zaxira (rezerv) server va ishchi holatdagi baza, asosiy serverdagi ma'lumotlarni to'liq ko'chirish imkoniyati | Baza replikatsiyasi/zaxira nusxa, fayllar sinxronizatsiyasi, failover tartibi |
| 7 | Shaxsiy identifikatsiya kodi bilan kirish; har bir foydalanuvchi amallari tarixini kuzatish | Audit jurnali (kim, qachon, nima), rollar |
| 8 | Klient orqali audio-video ni serverga yuklash | Katta fayllar uchun bo'laklab/davom ettiriladigan yuklash |
| 9 | Bir nechta format: wav, mp3, avi, mp4, ... | ffmpeg orqali dekodlash, format tekshiruvi |
| 10 | "Audio Processing" (shovqin tozalash, Normalization) bilan to'liq tozalash va tayyor mahsulotni yuklab olish | Audio va videodagi ovozni tozalash, natijani qayta yig'ish |
| 11 | "Speaker Diarization" (6-8+): 8 tagacha yoki ko'p suhbatdoshni aniqlash va ajratish; ovoz namunasi yuklanganda butun faylda shu shaxsga tegishli qismlarni topib ajratish | pyannote.audio diarizatsiyasi + speaker embedding bilan namunani moslashtirish (identifikatsiya) |
| 12 | Deep Learning asosida; **SNR ni 80-90% gacha yaxshilash**; to'liq offline model | Bu mezonni aniq o'lchov birligi bilan belgilang (pastga qarang) |
| 13 | Klient qismida arxiv va kutubxona | Yuklangan/tozalangan fayllar, tarix, qidiruv |
| 14 | Shamol, mashina, konditsioner, fon, hayvon ovozi, idish-tovoq shovqinlarini tozalash; avtomatik va professional sozlash rejimlari; 10 GB gacha fayllar; Batch rejim | Shovqin sinflari bo'yicha test to'plami; ikki rejim (auto/pro parametrlar); oqimli (streaming) qayta ishlash; navbat |

## "SNR ni 80-90% yaxshilash" talabini aniqlashtirish
Matnda o'lchov birligi yo'q: bu dB dagi yaxshilanishmi, nisbiy foizmi yoki boshqa narsami noma'lum. Dissertatsiyada shunday yozing: "SNR yaxshilanishi ΔSNR = SNR_chiqish − SNR_kirish (dB) bilan o'lchanadi" va foiz talabi qanday tushunilganini ilmiy rahbar/buyurtmachi bilan kelishing. Kelishilgan ta'rifni 4.2 da ishlating. Natijani faqat haqiqiy o'lchovdan yozing.

## Texnik vositalar
**Server:** 2x Intel Xeon Gold 6240, 8x32 GB RDIMM (256 GB), 2x960 GB SSD, 8x8 TB HDD, RAID kontroller, DVD±RW, 1+1 zaxira quvvat bloki 750 W, Broadcom 57416 10GbE va 5720 1GbE tarmoq kartalari. **GPU ko'rsatilmagan**, demak server inferensi CPU da bo'lishi kutiladi.

**Klient:** Intel i7-12700 (4.9 GHz gacha), Gigabyte B660M (hujjatda "B600M"), DDR4 3200 MHz 8 GB, SSD 500 GB + HDD 1 TB.

Natijalar:
- Whisper large-v3 kabi og'ir model CPU da sekin. int8 kvantlash (masalan, CTranslate2/faster-whisper), ONNX Runtime va pruning ni qo'llang va tezlikni (RTF) shu qurilmalarda o'lchang. Bu gipotezaga ham mos keladi.
- Fine-tuning (o'qitish) uchun GPU kerak. Foydalanuvchida GPU bormi yoki Colab/bulut kerakmi, so'rang. Faqat o'qitish bulutda, tayyor model esa offline ishlaydi, deb yozing.
- 10 GB fayl 8 GB RAM li klientda butunlay xotiraga yuklanmasligi kerak: bo'laklab (chunk) qayta ishlash va oqim.

## Texnologiya steki
Reja bo'yicha "JAVA, Web, Python". Tavsiya (foydalanuvchi tasdiqlaydi): AI serveri Python (FastAPI/Celery yoki shunga o'xshash navbat) + baza (PostgreSQL) + web-klient yoki Java klient. Tanlovni asoslab, III bobda tushuntiring.

## Hujjatlashtirish
III bobda: server modullari (autentifikatsiya, yuklash, navbat, AI ishchilar, arxiv, audit, zaxira), klient oynalari (kirish, yuklash, jarayon, natija, arxiv, sozlamalar), ma'lumotlar bazasi sxemasi, API ro'yxati, ketma-ketlik diagrammalari.
